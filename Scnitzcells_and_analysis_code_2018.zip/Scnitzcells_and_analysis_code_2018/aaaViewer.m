

%% SigL movies

% \\THECUSAUR\SigB\Sofi_MATRIX\2011-06-22-SofiMatrix1\sub
% 31    32
% 
% \\THECUSAUR\SigB\Sofi_MATRIX\2011-06-23-sofimatrix2\sub
% 20 21



%%
cd(fileparts(mfilename('fullpath')));
close all;

% mydir = '\\THECUSAUR\SigB\Sofi_MATRIX\2011-06-22-SofiMatrix1\sub'; %sub dir, no slash at end
% pos = '32'; %2 character string
% channel = 'y-'; %dash at end

mydir = '\\nasowitz\jpark\Movies\2012-05-01-pspacBTuW-cp-rn-sg'; %img dir, no slash at end
pos = '03'; %2 character string
channel = 'y-'; %dash at end

%% 
basenameDir = dir([mydir filesep '*-01-p-001.tif']);
basename = basenameDir.name(1:end-12);

%%

imgList = dir([mydir filesep basename pos '_1-' channel '*']); imgList = {imgList.name};
figure;
for imgctr = 1:length(imgList)
    a = imread([mydir filesep imgList{imgctr}]);
    imshow(a,[]);    
    text(100,10,num2str(imgctr),'color','g','fontsize',20)
    clear('a');
    pause; %pause(.01); 
end

