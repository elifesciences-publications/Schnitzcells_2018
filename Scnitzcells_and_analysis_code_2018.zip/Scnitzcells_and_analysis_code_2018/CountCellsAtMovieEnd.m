



%% User Settings
mydir = 'C:\JinData\2013-05-23-delUXsigW\sub\2013-05-23'; %put date folder, w/o backslash


%% 
fldlist = dir([mydir filesep 'acdc*']); fldlist = {fldlist.name};

for fldctr = 1:length(fldlist)
    seglist = dir([mydir filesep fldlist{fldctr} filesep 'segmentation' filesep 'acdc-*']);
    load([mydir filesep fldlist{fldctr} filesep 'segmentation' filesep seglist(end).name]); 
    %disp([num2str(fldctr) '     ' num2str(max(max(Lc)))]);
    disp(num2str(max(max(LNsub))));
    clear('seglist','acdc*','LNsub');
end