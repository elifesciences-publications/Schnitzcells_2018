function snew = getdatacomparefuncall_final(s);

snew = s;

getareapulse = [];
durationtotalyfp = [];
celltime = [];
cellpulse = [];
nocellpulse = [];
cellcycletime = [];
nopulse = [];
freqpulse = [];
freqnorm = [];
meanprom = [];
pulseheight = [];
areapulse = [];
peakstart = [];
durationhalfmax = [];
areahalfmax = [];
pulsehalfmax = [];
peakstarthalf = [];
numberschnitz = [];
cellcyclepulse = [];
meanlen = [];
peakphaseJon = [];
m = 1;
for d = 1:length(s)
    for e = 1:length(s(d).peaksY)
          if s(d).peaksY(e) > 0         
        try
                   durationtotalyfp(m) = s(d).peakdurationAY(e);
                    catch
                    durationtotalyfp(m) = 0
                    end
                   durationhalfmax(m) = s(d).halfmaxduration(e);
                   %areapulse(m) = s(d).areapulseAY(e)
                   m = m+1;
                end
             end
end
   

m = 1;
for d = 1:length(s)
    for e = 1:length(s(d).peaksY)
        if s(d).peaksY(e) > 0
        
                        % durationtotalyfp(m) = s(d).peakdurationAY(e);
                        areapulse(m) = s(d).areapulseAY(e);
                        pulseheight(m) = s(d).peakheightAY(e);
                        pulsehalfmax(m) = s(d).heighthalfmax(e);
                        cellcyclepulse(m) = length(s(d).frames);
                        areahalfmax(m) = s(d).areahalfmax(e);
                        % peakstart(m) = (e-s(d).peakleftY(e))/length(s(d).peaksY);
                        %    peakstarthalf(m) = (e-s(d).beginpulse(e))/length(s(d).peaksY);
                        peakstart(m) = (e-s(d).peakleftY(e));
                        peakstarthalf(m) = (e-s(d).beginpulse(e));
                        peakphaseJon(m) = s(d).peaksYphase(e);
                        m = m+1;
                    end
              end
        
end

m = 1;
for d = 1:length(s)
    if length(s(d).AYlen)>1
        %  durationtotal(m) = s(d).peakduration(e);
        meanprom(m) = mean(s(d).AYlen);
        meandlen(m) = mean(s(d).mu);
        m = m+1;
    end
end

m = 1;
n =1;
o = 1;
p = 1;
for d = 1:length(s)    
  
            celltime(n) = length(s(d).frames);
            meansigb(n) = mean(s(d).AYlen);
            n = n+1;
            if max(s(d).peaksY) > 0
                cellpulse(o) = length(s(d).frames);
                meansigbpulse(o) = mean(s(d).AYlen);
                schnitzpulse(o) = d; 
                o = o+1;
            else
                nocellpulse(p) = length(s(d).frames);
                meansigbnopulse(p) = mean(s(d).AYlen);
                schnitznopulse(p) = d;
                p = p+1;
       
    end
    
    for e = 1:length(s(d).frames)
        %  durationtotal(m) = s(d).peakduration(e);
        numberschnitz = m;
        m = m+1;
    end
end

d = [];
m = 1;
peakphase = [];
for i = 1:length(s)
    if s(i).E > 0

        if s(i).P > 0
            for d = 1:length(s(i).peaksY)
                if length(s(i).peaksY) == 5;
                    if s(i).peaksY(d) == 1
                        peakphase(m) = (d-1)/(length(s(i).peaksY)-1);
                        m = m+1;
                    end
                end
            end
        end
    end

end

peakstart;
cellcycletime = numberschnitz/length(s)/4;
nopulse = length(areapulse); 
freqpulse = nopulse/(n-1);

freqpulse;%jin,2010/08/14 - denominator should be n-1, 
                           %since n overcounts # of schnitzes by 1
                           %jin - also note that freqpulse counts #pulses
                           %per cell cycle, rather than per unit time
%freqnorm = freqpulse/mean(celltime/4);
 freqnorm = nopulse/sum(celltime/4);
 lendude = mean(meandlen);
 
 snew(1).peakstarthalf = peakstarthalf;
   snew(1).peakphase = peakphase;
   snew(1).cellcycletime = mean(celltime)/4;
   snew(1).nopulse = nopulse;
   snew(1).freqpulse = freqpulse;
   snew(1).freqnorm = freqnorm;
   snew(1).durationhalfmax = durationhalfmax;
   snew(1).areahalfmax = areahalfmax;
   snew(1).pulsehalfmax = pulsehalfmax;
   snew(1).paperlikelyhood = mean(pulsehalfmax/n);
   snew(1).totalcellsanalysed = n;
   snew(1).cellcyclepulse = cellcyclepulse;
   snew(1).meanprom = mean(meanprom);
   snew(1).meanpromall = meanprom;
   snew(1).lendude = lendude;
   snew(1).peakphaseJon = peakphaseJon;