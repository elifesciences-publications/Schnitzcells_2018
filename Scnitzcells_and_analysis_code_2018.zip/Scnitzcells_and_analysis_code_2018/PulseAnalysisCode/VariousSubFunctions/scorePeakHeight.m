function heightScore = scorePeakHeight(t, y, middle);
% function heightScore = scorePeakHeight(t, y, middle)
%
% 'scorePeakHeight' analyzes a peak located at 'middle' and scores the peak's
% height, returned as 'heightScore.'
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

heightScore = y(middle);
