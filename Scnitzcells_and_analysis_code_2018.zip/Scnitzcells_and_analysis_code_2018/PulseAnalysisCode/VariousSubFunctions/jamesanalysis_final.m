function [peakheight peakratio peakduration areapulse leftshift] = jamesanalysis_final(t, ysmooth, peak)
% function heightScore = scorePeakHeight(t, y, middle)
%
% 'scorePeakHeight' analyzes a peak located at 'middle' and scores the peak's
% height, returned as 'heightScore.'
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
peaks = []; % Values of 't' vector where peaks are located.
peakInds = []; % Indices into 'y' vector where peaks are located.
peakScores = [];
peakduration = [];
areapulse = [];
peakratio = [];
peakheight = [];

peakno = peak;

    for i = 1:peakno-3  %as we move left along PA, where is minimum?
        if ysmooth(peakno-i) <= ysmooth(peakno-(i-1))
            if ysmooth(peakno-i)<= ysmooth(peakno-(i+1))
                peakminleft = peakno-i;
                break
            else
                peakminleft = 1;
            end
        end
    end

    for i  = 1:(length(ysmooth)-(peakno+3))
        if ysmooth(peakno+(i+1))<= ysmooth(peakno+i)
            if(ysmooth(peakno+(i+1)))<= ysmooth(peakno+(i+2))
               %jin noticed error 12/08/10
               % old code 
               % peakminright = peakno + (i);
               peakminright = peakno + (i+1);
               break
            end
        end
        peakminright = length(ysmooth);
    end

for a = 1:length(ysmooth);
    if ysmooth(a)<0;
        ysmooth(a) = 0;
    end
end

    try
        averagepeakmin = (ysmooth(peakminright)+ysmooth(peakminleft))/2;
    catch
        peakminright = length(ysmooth);
        averagepeakmin = (ysmooth(peakminright)+ysmooth(peakminleft))/2;
    end
    peakheight = ysmooth(peakno)-averagepeakmin;
    if peakheight > 0;
        d = [ysmooth(peakminright) ysmooth(peakminleft) ];
        minpeak = max(d); 
        %used to be min(d); 
  %cd   peakratio = peakheight/ysmooth(peakno); 
   % peakratio = peakheight/(minpeak+peakheight); %will be putting this back in 10 minutes
  peakratio = (ysmooth(peakno)-minpeak)/ysmooth(peakno);
  averagepeakmin = (ysmooth(peakminright)+ysmooth(peakminleft))/2;
    y = (ysmooth(peakminleft:peakminright));
    x = [peakminleft:peakminright];
    xi = peakminleft:0.25:peakminright;
    yi = interp1(x,y,xi);
    peakmid = peakheight/2+averagepeakmin;
    for e = 1:length(xi) 
        if yi(e) > peakmid
            ylmid = e;
            break
        end
    end
    for e = 1:length(xi)
        if yi(length(xi)-e+1) > peakmid
            yrmid = length(xi)-e+1;
            break
        end
    end

    peakduration=(yrmid-ylmid)/4;

    areapulse = polyarea(xi(ylmid:yrmid),yi(ylmid:yrmid));
    leftshift = peak -peakminleft;
    else
        leftshift = 0;
        areapulse = 0;
        pulseduration = 0;
        peakratio = 0;
    end
        
    %         areapulse = 0;

