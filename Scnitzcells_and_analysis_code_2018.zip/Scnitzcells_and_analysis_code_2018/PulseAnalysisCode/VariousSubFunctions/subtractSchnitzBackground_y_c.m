function s = subtractSchnitzBackground_y_c(s,backY,backC)


% codefolder = fileparts(fileparts(mfilename('fullpath')));
% load([codefolder filesep 'BackgroundTimeDependence' filesep 'smoothedBack.mat']);

% for schctr = 1:length(s)
%     for frmctr = 1:length(s(schctr).frames)
%        frm = s(schctr).frames(frmctr); 
%        backC = polyval(pC,frm);
%        backY = polyval(pY,frm); 
%       
%        s(schctr).MC(frmctr) = s(schctr).MC(frmctr) - backC;
%        s(schctr).MY(frmctr) = s(schctr).MY(frmctr) - backY;
%     end
% end

for schctr = 1:length(s)
    s(schctr).MC = s(schctr).MC - backC;    
    s(schctr).MY = s(schctr).MY - backY;    
end



end %end of main function