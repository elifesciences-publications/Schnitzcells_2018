function trace = extractTrace(s, schnitzNum, traceName)
% trace = extractTrace(s, schnitzNum, traceName)
% returns the values in field 'traceName' starting from schnitzNum and
% working backwards.

trace = [];

if isfield(s, traceName)

    while ( s(schnitzNum).P > 0 )
        trace = [getfield(s(schnitzNum), traceName) trace];
        schnitzNum = s(schnitzNum).P;
    end

    trace = [getfield(s(schnitzNum), traceName) trace];

else
    disp([traceName ' does not seem to be a valid field.']);
end