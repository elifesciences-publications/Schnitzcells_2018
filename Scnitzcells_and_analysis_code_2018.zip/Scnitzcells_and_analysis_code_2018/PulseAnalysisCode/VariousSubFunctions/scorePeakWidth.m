function [widthScore, pixelsLeft, pixelsRight] = scorePeakWidth(t, y, middle, visualize)
% function [widthScore, pixelsLeft, pixelsRight] = scorePeakWidth(t, y, middle, visualize)
%
% 'scorePeakWidth' analyzes a peak located at 'middle' and scores the peak's
% width, returned as 'widthScore.' it also returns the number of pixels to
% the middle's left counted in the peak ('pixelsLeft'), and similarly to
% the right ('pixelsRight').
% if visualize = 1, plot while analyzing; else, do not plot
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
widthScore = 0;
pixelsLeft = 0;
pixelsRight = 0;
l = length(t);

% Determine peak width to the right

j = middle;
nUpSlopeRight = 0; % counter tracking the number of consecutive time steps 
% second derivative is greater than 0.
while j < l % keep strictly <
    d2y = y(j+1) - 2*y(j) + y(j-1);
    if visualize
        plot(t,y,'.-')
        hold on
        plot(t((j-1):(j+1)),y(j-1:j+1),'ro','MarkerFaceColor','r')
        drawnow
        pause(.05)
    end
    if d2y > 0 
        break; % Reset counter if we see downward curviture
    else 
        nUpSlopeRight = nUpSlopeRight + 1;
        j = j + 1;
    end
end
j = middle;
nUpSlopeLeft = 0;  

while j > 1 
    d2y = y(j+1) - 2*y(j) + y(j-1);
    if visualize
        plot(t,y,'.-')
        hold on
        plot(t((j-1):(j+1)),y(j-1:j+1),'go','MarkerFaceColor','g')
        drawnow
        pause(.05)
    end
    if d2y > 0 
        break; % Reset counter if we see downward curviture
    else
        nUpSlopeLeft = nUpSlopeLeft + 1;
        j = j - 1;
    end
end

if ( (nUpSlopeRight > 0) && (nUpSlopeLeft > 0) )
    widthScore = nUpSlopeRight + nUpSlopeLeft-1; % added in subtract 1 to avoid overcounting middle peak - JIN 10/08/12;
    pixelsLeft = nUpSlopeLeft;
    pixelsRight = nUpSlopeRight;
else
    widthScore = 0;
end
hold off
    
