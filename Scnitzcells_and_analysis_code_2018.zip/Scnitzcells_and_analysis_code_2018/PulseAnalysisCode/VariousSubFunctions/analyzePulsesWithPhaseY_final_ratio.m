function s = analyzePulsesWithPhaseY_final_ratio(s, colorstring, usesmoothed, visualize, ratioA)
%function s = analyzePulses(s, colorstring, usesmoothed, visualize)
%
% analyzePulses adds the following fields to each schnitz (for each color X):
% a. peakIndicesX
% b. peaksX
% c. scoresX
% d. pulseWidthsX
% e. pulseAreaX
%
% if usesmoothed = 0, no smoothing is performed
% if usesmoothed = 1, a bfilt(5) is performed on AXlen
% if visualize = 1, plot traces while analyzing; else, no plotting.
%
% USER NOTE!!!!! If analyzing RFP make sure to properly use framesMid or
% framesRFP in ALL locations!!!
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%Update from Jon:  I wanted the phasing information embedded into the
%schnitz structure from the beginning.  Note, as per James, the phasing
%information for root schnitzes will not be accurate because the length of
%the schnitz is incomplete.


for j = 1 : length(s)
    s(j).peakIndicesC = [];
    s(j).peaksC = zeros(1,length(s(j).frames));
    s(j).scoresC = zeros(1,length(s(j).frames));
end
for j = 1 : length(s)
    s(j).peakIndicesY = [];
    s(j).peakIndplotY = [];
    s(j).peaksY = zeros(1,length(s(j).framesMid));
    s(j).peaksYphase = zeros(1,length(s(j).framesMid));
    s(j).scoresY = zeros(1,length(s(j).framesMid));
    s(j).heighthalfmax  = zeros(1,length(s(j).framesMid));
    s(j).ratiopeak = zeros(1,length(s(j).framesMid));
    s(j).halfmaxduration =zeros(1,length(s(j).framesMid));
    s(j).areahalfmax = zeros(1,length(s(j).framesMid));
    s(j).beginpulse = zeros(1,length(s(j).framesMid));
end
for j = 1 : length(s)
    s(j).peakIndicesR = [];
    s(j).peaksR = zeros(1,length(s(j).frames));
    s(j).scoresR = zeros(1,length(s(j).frames));
end


fends = find( ([s.D] .* [s.E]) == 0 );

for j = fends
    
    
    % Find peaks in appropriate colors
    if findstr(colorstring, 'c')        
        frames = extractTrace(s, j, 'framesMid');
        AClen = extractTrace(s, j, 'AClen');
        if usesmoothed
            AClen = bfilt(AClen,5);
        end
        [peaksAC,widthsAC,areasAC] = findmax2(frames, AClen, 7, 2, 0, visualize);
    end
    if findstr(colorstring, 'y')
        tmean = extractTrace(s, j, 'frames');
        lenc = extractTrace(s,j,'len');
        ymean = extractTrace(s, j, 'MY');
        framesMid = extractTrace(s, j, 'framesMid');
        AYlen = extractTrace(s, j, 'AYlen');
        if usesmoothed
            AYlen = bfilt(AYlen,5);
        end
        [peaksAY,widthsAY,areasAY,leftpeak,peakplotAY, heighthalfmax,...
            ratiopeak, halfmaxduration,  areahalfmax, beginpulse,latency] = findmax2_final(tmean, ymean, lenc,...
            framesMid, AYlen, 7, 0, 7.5, ratioA, visualize) ;
        %this was set at 5 and 0.25 --- then 15 and 0.3 - then 15 and 0.1
        %then 7.5 0.3
    end
    
    if findstr(colorstring, 'r')
        frames = extractTrace(s, j, 'framesRFP');
        ARlen = extractTrace(s, j, 'ARlen_RFP');
        if usesmoothed
            ARlen = bfilt(ARlen,5);
        end
        [peaksAR,widthsAR,areasAR] = findmax2(frames, ARlen, 7, 5, 0, visualize);
    end
    
    % Assign peak locations in schnitz structure
    
    k = j;
    while ( s(k).P > 0 )
        
        % Check if peaksAC and peaksAY elements are in this particular
        % schnitz
        if findstr(colorstring, 'c')
            for l = 1 : length(peaksAC)
                peakInd = find(s(k).framesMid == peaksAC(l));
                if peakInd
                    s(k).peakIndicesC = [peaksAC(l) s(k).peakIndicesC];
                    s(k).peaksC(peakInd) = 1;
                    s(k).pulseWidthsC(peakInd) = widthsAC(l);
                    s(k).pulseAreaC(peakInd) = areasAC(l);
                    
                end
            end
        end
        if findstr(colorstring, 'y')
            for l = 1 : length(peaksAY)
                peakInd = find(s(k).framesMid == peaksAY(l));
                if peakInd
                    s(k).peakIndicesY = [peaksAY(l) s(k).peakIndicesY];
                    s(k).peakIndplotY = [peakplotAY(l) s(k).peakIndplotY];
                    s(k).peaksY(peakInd) = 1;
                    s(k).peaksYphase(peakInd) = (peakInd-1)/(length(s(k).peaksYphase)-1);
                    s(k).pulseWidthsY(peakInd) = widthsAY(l);
                    s(k).areapulseAY(peakInd) = areasAY(l);
                    s(k).peakdurationAY(peakInd) = widthsAY(l);
                    s(k).peakheightAY(peakInd) = areasAY(l);
                    s(k).peakleftY(peakInd) = leftpeak(1);
                    s(k).heighthalfmax(peakInd)  = heighthalfmax(l);
                    s(k).ratiopeak(peakInd) = ratiopeak(l);
                    s(k).halfmaxduration(peakInd) = halfmaxduration(l);
                    s(k).areahalfmax(peakInd) = areahalfmax(l);
                    s(k).beginpulse(peakInd) = beginpulse(l);
                    s(k).latency(peakInd) = latency(l);
                end
            end
        end
        if findstr(colorstring, 'r')
            for l = 1 : length(peaksAR)
                peakInd = find(s(k).framesRFP == peaksAR(l));
                if peakInd
                    s(k).peakIndicesR = [peaksAR(l) s(k).peakIndicesR];
                    s(k).peaksR(peakInd) = 1;
                    s(k).pulseWidthsR(peakInd) = widthsAR(l);
                    s(k).pulseAreaR(peakInd) = areasAR(l);
                end
            end
        end
        
        
        k = s(k).P;
    end %end for while function
    
    % Perform this scan one last time to take care of root case.
    if findstr(colorstring, 'c')
        for l = 1 : length(peaksAC)
            peakInd = find(s(k).framesMid == peaksAC(l));
            if peakInd
                s(k).peakIndicesC = [peaksAC(l) s(k).peakIndicesC];
            end
        end
    end
    if findstr(colorstring, 'y')
        for l = 1 : length(peaksAY)
            peakInd = find(s(k).framesMid == peaksAY(l));
            if peakInd
           s(k).peakIndicesY = [peaksAY(l) s(k).peakIndicesY];
           s(k).peakIndplotY = [peakplotAY(l) s(k).peakIndplotY];
           s(k).peaksY(peakInd) = 1;
                    s(k).peaksYphase(peakInd) = (peakInd-1)/(length(s(k).peaksYphase)-1);
                    s(k).pulseWidthsY(peakInd) = widthsAY(l);
                    s(k).areapulseAY(peakInd) = areasAY(l);
                    s(k).peakdurationAY(peakInd) = widthsAY(l);
                    s(k).peakheightAY(peakInd) = areasAY(l);
                    s(k).peakleftY(peakInd) = leftpeak(1);
                    s(k).heighthalfmax(peakInd)  = heighthalfmax(l);
                    s(k).ratiopeak(peakInd) = ratiopeak(l);
                    s(k).halfmaxduration(peakInd) = halfmaxduration(l);
                    s(k).areahalfmax(peakInd) = areahalfmax(l);
                    s(k).beginpulse(peakInd) = beginpulse(l);
                    s(k).latency(peakInd) = latency(l);
            end
        end
    end
    if findstr(colorstring, 'r')
        for l = 1 : length(peaksAR)
            peakInd = find(s(k).framesMid == peaksAR(l));
            if peakInd
                s(k).peakIndicesR = [peaksAR(l) s(k).peakIndicesR];
            end
        end
    end
end

% Prune Non-unique peaks

if findstr(colorstring, 'c')
    for j = 1 : length(s)
        s(j).peakIndicesC = unique(s(j).peakIndicesC);
    end
end
if findstr(colorstring, 'y')
    for j = 1 : length(s)
        s(j).peakIndicesY = unique(s(j).peakIndicesY);
    end
end
if findstr(colorstring, 'r')
    for j = 1 : length(s)
        s(j).peakIndicesR = unique(s(j).peakIndicesR);
    end
end


