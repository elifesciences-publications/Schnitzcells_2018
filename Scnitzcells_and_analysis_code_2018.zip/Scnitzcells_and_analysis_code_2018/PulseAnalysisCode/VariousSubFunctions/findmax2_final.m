function [peaks, peakWidths, peakAreas, pixelsLeft,peakInds, heighthalfmax, ratiopeak, halfmaxduration,  areahalfmax, beginpulse,peakinterval] = findmax2_final(ty,ymean, lenc, t, y, winsize, widthThresh, heightThresh, ratioThresh, visualize)
% function peaks = findmax2(t, y, winsize, widthThresh, heightThresh, visualize) 
% winsize should be odd;
%
% Finds local maxima of the vector 'y' using the window 'winsize.'
% Evaluates whether each local maxima is a peak using widthThresh and
% heightThresh
%
% if 'visualize' = 1, plot traces while analyzing; else, do not.

middle = round(winsize/2);
T = length(t);
peaks = []; % Values of 't' vector where peaks are located.
peakInds = []; % Indices into 'y' vector where peaks are located.
peakScores = [];
peakWidths = [];
peakAreas = [];
pixelsLeft = [];
peakInds = [];
  heighthalfmax = [ ];
   ratiopeak = [];
 halfmaxduration = [];
 areahalfmax = [];
beginpulse = [];
if length(y) > 5  %JY: clearly some residual hack.
    
    %ysmooth = bfiltn(y,5,5);
    ysmooth = y; % y here is actually AYlen (yfp promoter activity)
else
    ysmooth = y; 
end
% for d = 1:length(ysmooth);
%     if ysmooth(d) <0
%         ysmooth(d) = 0;  
%     end
% end
for i = 2:(T-winsize+1), %T being framesMid
   if isempty(find(peakInds == i-1)) % protect against repeat peaks
        window = ysmooth(i:(i+winsize-1));
        if (window(middle) == max(window)) % first criterion -- is middle value the max in this window?
            
            % Get the width and height of the peak associated with this
            % point.
            [widthScore, pixelsLeft, pixelsRight] = scorePeakWidth(t, y, (i+middle-1), visualize);
            heightScore = scorePeakHeight(t, y, (i+middle-1));
            areaScore = scorePeakArea(t, y, (i+middle-1), pixelsLeft, pixelsRight);
            [halfmaxheight, peakratio, duration, halfmaxarea,leftshift] = jamesanalysis_final(t,ysmooth, (i+middle-1));
            if ( (widthScore >= widthThresh) && (halfmaxheight >= heightThresh) && peakratio >= ratioThresh)
                peaks = [peaks t(i+middle-1)];
                peakInds = [peakInds (i+middle-1)];
                peakWidths = [peakWidths widthScore];
                peakAreas = [peakAreas areaScore];
                heighthalfmax = [ heighthalfmax halfmaxheight];  %This is really full peak amplitude, ie peakmax-averagepeakmin
                ratiopeak = [ratiopeak peakratio];
                halfmaxduration = [halfmaxduration duration];
                areahalfmax = [areahalfmax halfmaxarea];
                beginpulse = [beginpulse leftshift];
                %peakScores = [peakScores score];
            end
        end;
    end
end;
if length(peaks) > 1

for m = 1:length(peaks)-1
    peakinterval(m) = peaks(m+1)-peaks(m);
end

peakinterval = [0 peakinterval];
else
    peakinterval = 0;
end

%  peakInds = p ea kInds+middle-1;
if visualize
    figure(1)
    plot(t,ysmooth,'-b',peaks,y(peakInds),'bo',t,ysmooth,'-xb');
    drawnow
      figure(2)
      plot(ty,ymean,'-g');
      figure(3)
      plot(ty,lenc,'-b');
    pause
 
      
 end 
