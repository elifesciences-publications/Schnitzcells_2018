function areaScore = scorePeakArea(t, y, middle, pixelsLeft, pixelsRight);
% function heightScore = scorePeakArea(t, y, middle)
%
% 'scorePeakArea' analyzes a peak located at 'middle' and returns the peak's height, 
% as 'areaScore.'
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%heightScore = y(middle);
areaScore = sum(y( (middle - pixelsLeft + 1) : (middle + pixelsRight -1) ));
%added in subtract and add 1 to pixelsLeft and to pixelsRight due to
%overcount leading to incorrect area size (overestimate) JIn 10/08/12

