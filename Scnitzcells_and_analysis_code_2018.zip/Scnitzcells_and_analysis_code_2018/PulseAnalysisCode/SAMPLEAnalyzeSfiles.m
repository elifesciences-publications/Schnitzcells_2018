


%%
% w at 15 iptg
% amp     102.4 pm 12.4	
% dur	1.01 pm .08
% freq	.077 pm .022
% 
% w at 0 iptg
% amp	41.9 pm 11.5
% dur	1.2  pm .20
% freq	.02  pm .02




%% Initial Things
% load('sfiles.mat');



%% 

sList = whos('s_W_0iptg_*'); sList = {sList.name};
amplitudes = cell(1,length(sList));
durations = cell(1,length(sList));
frequencys = cell(1,length(sList));

% for sigctr = 1:length(SigList)
%    movdir = who(['s_' SigList{sigctr} '_*']); %list of s structures for this sig
%    
%    for movctr = 1:length(movdir)
%        s = eval(movdir{movctr});      
%        amplitudes{sigctr}{end + 1} = s(1).pulsehalfmax; %saving pulse amplitudes
%        durations{sigctr}{end + 1} = s(1).durationhalfmax/4; %saving pulse durations
%        frequencys{sigctr}{end + 1} = s(1).freqnorm; %saving pulse frequencies
%    end
% end

for sctr = 1:length(sList)
    s = eval(sList{sctr});
    
    amplitudes{sctr}{end + 1} = s(1).pulsehalfmax; %saving pulse amplitudes
    durations{sctr}{end + 1} = s(1).durationhalfmax/4; %saving pulse durations
    frequencys{sctr}{end + 1} = s(1).freqnorm; %saving pulse frequencies
end