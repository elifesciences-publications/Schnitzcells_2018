

    




    
[p,s] = compileschnitzZeroBack(p);
s = subtractSchnitzBackground(s,271); %...(s,backY)
s = promoterActivity_final(s,0.05);  %...(s,gamma_fudge)
s = analyzePulsesWithPhaseY_final_ratio(s,'y',0,0,.5);
s = getdatacomparefuncall_final(s);






%% Final Things
% save('sfiles.mat','s_*');
% close all; %there's some script that generates an empty figure...annoying



% %% Initial Things
% cd(fileparts(mfilename('fullpath'))); %cd into directory of this script
% clear all; clc; close all;
% load('37deg40mpa_Sonly.mat');
% 
% %% Compile Movie Data into Various Data Structures, for later Plotting Needs
% S_fileList = who('s_*');
% SigList = unique(cellfun(@(x) x(3:end-2) , S_fileList, 'uniformoutput',false)); %e.g. SigList = {'B' 'I' ...};
% SigList(cell2mat(cellfun(@(x) ~isempty(strfind(x,'I')),SigList,'uniformoutput',false))) = []; %removing 'I'
% SigLabel = SigList; SigLabel{cellfun(@(x) ~isempty(strfind(x,'Ydbs')),SigLabel)} = 'W'; %changing Ydbs to W
% 
% 
% amplitudes = cell(1,length(SigList));
% durations = cell(1,length(SigList));
% frequencys = cell(1,length(SigList));
% for sigctr = 1:length(SigList)
%    movdir = who(['s_' SigList{sigctr} '_*']); %list of s structures for this sig
%    
%    for movctr = 1:length(movdir)
%        s = eval(movdir{movctr});      
%        amplitudes{sigctr}{end + 1} = s(1).pulsehalfmax; %saving pulse amplitudes
%        durations{sigctr}{end + 1} = s(1).durationhalfmax/4; %saving pulse durations
%        frequencys{sigctr}{end + 1} = s(1).freqnorm; %saving pulse frequencies
%    end
% end
% 
% %% Create Bar Graph of Pulse Amplitude,Durations, and Frequencuy for Various Sigmas...Also write the data to an Excel File
% proplist = {'amplitudes' 'durations' 'frequencys'};
% xlswrite('Datasummary.xlsx',SigLabel',1,'B6');
% for prpctr = 1:length(proplist)
%     property = eval(proplist{prpctr});
%     figure; hold on;
%     meanProp = cellfun(@(x)  mean(cellfun(@(y) mean(y) , x))     , property);
%     stderrProp = cellfun(@(x)  std(cellfun(@(y) mean(y) , x))/sqrt(length(x))     , property);
%     bar(meanProp); hold on ; errorbar(1:length(SigList),meanProp,stderrProp,'.');
%     hold off;
% 
%     set(gca,'Xtick',1:length(SigList),'XtickLabel', SigLabel);
%     set(gca,'FontSize',17);   
%     xlabel('Sigma Factor');
%     ylabel(['Pulse ' upper(proplist{prpctr}(1)) proplist{prpctr}(2:end-1) ]);    
%     %print(['Figure1-' upper(proplist{prpctr}(1)) proplist{prpctr}(2:end-1)],'-dpdf');
% 
%     %Writing Data to Excel File
%     xlswrite('Datasummary.xlsx',{[proplist{prpctr} ' mean']},1,['A' num2str(4+3*prpctr)]);
%     xlswrite('Datasummary.xlsx',meanProp,1,['B' num2str(4+3*prpctr)]);    
%     xlswrite('Datasummary.xlsx',{[proplist{prpctr} ' error']},1,['A' num2str(5+3*prpctr)]);
%     xlswrite('Datasummary.xlsx',stderrProp,1,['B' num2str(5+3*prpctr)]);
% end
