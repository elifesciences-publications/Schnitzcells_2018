function I= maxI(a);
% function I= maxI(a);
%
% returns index of maximum

[am, I]= max(a);