function I= minI(a);
% function I= minI(a);
%
% returns index of minimum

[am, I]= min(a);