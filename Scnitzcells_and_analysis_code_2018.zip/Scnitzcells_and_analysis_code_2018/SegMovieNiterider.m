


%% User Settings
%cd into directory of interest!
poslist = [2 3 13 14 15 34 35]; %position number, set as number(or vector of numbers), not as string
imgdir = '\\nasowitz\jpark\ZeroMPAmovies\2011-06-30-sofinompa2-selected\sub'; %no slash at end
    %no slash at end, put in the 'sub' folder
    

%% Running Segmentation on Movies
%Find datefolder name
D = dir([imgdir filesep '201*-*-*']); D = D(vertcat(D.isdir));
if length(D) ~= 1
    error('Either a date directory was not found in the sub folder, or there was more than 1 identified date folder');
end
datestr = D(1).name; 
clear D;

%Finding basename
basenamedir = dir([imgdir filesep '*-*-y-001.tif']);
basenamesetpoints = strfind(basenamedir(1).name,'-');
basename = basenamedir(1).name(1:basenamesetpoints(1)-1);  

%Check directory
if ~strcmp(cd,imgdir)
    error('current directory and the user'' inputted directory are different');
end

%now running through movies and segmenting each one
for posctr = 1:length(poslist)
    pos = poslist(posctr);
    p = initschnitz([basename '-' num2str(pos,'%1.2d') '_1'],...
        datestr,...
        'bacillus',...
        'rootDir',imgdir,...
        'imageDir',imgdir);
    p = segmoviefluorjonlimit(p); %found in \\thecusaur\sigb\randomshare
end

clear p pos posctr poslist imgdir datestr basenamedir basenamesetpoints;

