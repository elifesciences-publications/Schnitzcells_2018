function MovieCropGui2 
%*****************User Defined Settings
%Step 1
    %make the img directory MATLAB's current directory

%*****************Creating the GUI.
f = figure('Visible','on','Position',[360,200,450,300]);

%buttons to the right of axes
hplayRect = uicontrol('Style','pushbutton','String','Play w/ Rect','Position',[315 205 70 25]...
    ,'Callback',{@playRectbutton_Callback});
hedit = uicontrol('Style','edit','String','01','Position',[315 40 30 15]);
heditFR = uicontrol('Style','edit','String','1 55','Position',[315 235 30 15]);
hgetframes = uicontrol('Style','pushbutton','String','Get Frames','Position', [315 65 70 25],'Callback',{@getframes_Callback});
hgetNextPosframes = uicontrol('Style','pushbutton','String','Get Next Position''s Frames','Position', [395 65 50 25],'Callback',{@getNextPosframes_Callback});
hplayloaded = uicontrol('Style','pushbutton','String','Play Loaded Frames','Position',[315 100 70 25],'Callback',{@playloadedbutton_Callback});
hpopup = uicontrol('Style','popupmenu','String',{'RFP','Phase','YFP','CFP'},'Position',[315 10 100 25],'Callback',{@popup_menu_Callback});
htext = uicontrol('Style','text','String','Select Data','Position',[100 5 100 15]);
ha = axes('Units','pixels','Position', [10 50 290 235]);

%buttons below axes
hBelgetNextPosframes = uicontrol('Style','pushbutton','String','Get Next Pos Frames','Position', [10 25 40 15],'Callback',{@getNextPosframes_Callback});
hBelback = uicontrol('Style','pushbutton','String','Back','Position', [55 25 40 15],'Callback',{@back_Callback});
hBelforward = uicontrol('Style','pushbutton','String','Forward','Position', [100 25 40 15],'Callback',{@forward_Callback});
hBelCurrFrameAsLastCropFrame = uicontrol('Style','pushbutton','String','Current Frame -> Last','Position', [145 25 40 15],'Callback',{@CurrFrameAsLastCropFrame_Callback});
hBelclicky = uicontrol('Style','pushbutton','String','Clicky','Position',[190 25 40 15],'Callback',{@clicky_Callback});
hBelSaveClicky = uicontrol('Style','pushbutton','String','SaveClicky','Position',[235 25 40 15],'Callback',...
    {@SaveClicky_Callback});


% Change units to normalized so components resize automatically.
set([f,hplayRect,hedit,heditFR,hgetframes,hgetNextPosframes,hplayloaded,hpopup,htext,ha],'Units','normalized');
set([hBelgetNextPosframes,hBelback,hBelforward,hBelCurrFrameAsLastCropFrame,hBelclicky,hBelSaveClicky],'Units','normalized');
set(f,'Name','MovieCropGUI2'); %Assign name to GUI
set(f,'Position',[.005 .2 .990 .73]); %bottom left corner X, bottom left corner Y, width, height
%movegui(f,'center'); %Move GUI to center of screen
%set(f,'Visible','on'); %make GUI visible

%*****************Setting initial conditions
%Finding basename
basenamedir = dir('*-*-y-001.tif');
basenamesetpoints = strfind(basenamedir(1).name,'-');
basename = basenamedir(1).name(1:basenamesetpoints(1)-1);  
clear basenamesetpoints basenamedir;

%Renaming 'imgdir', which holds directory where img's are stored
%%%%%imgdir must end up having 2 backslashes for a single backslash
%%%%%also must have 2 backslashes at end of directory name
%%%%%Example1 - 'C:\\Users\\enderval3\\Desktop\\SigD.Matrix.Movie\\';
%%%%Example2 - '\\THECUSAUR\\SigB\\JinData\\2012-01-20-pspacBscreenWM-cp-rn\\';
currdir = pwd; %currdir is a string containing current directory
strlength = length(currdir); counter = 2;
while counter < (strlength)
    if currdir(counter) == '\' && currdir(counter-1) ~= '\' && currdir(counter+1) ~= '\' 
       currdir = [currdir(1:counter) '\' currdir(counter+1:end)];
    end
    counter = counter + 1;
    strlength = length(currdir);    
end
imgdir = [currdir '\\'];

%Setting other initial conditions
position = '01'; %set as string
channel = 't'; %set as string, without any dashes

Mov = zeros(1,'uint16'); %Mov = zeros(1040,1392,60);
newMov = zeros(1,'uint16');
Rect = zeros(1,'uint16');
col = zeros(1,2);
row = zeros(1,2);
current_frame = 1;
total_frames = 1;

%*****************Function Callbacks     
    function SaveClicky_Callback(~,~)
        %CropMaskMatrix
        %position # , frameStart , frameEnd , Tmarg, Lmarg, Bmarg, Rmarg
        %everything stored as numbers, not strings
                
        %first check whether the matrix exists, if not -> make matrix
        disp('Start Clicky Save'); 
        if isempty(dir('CropMaskMatrix.mat'))
            CropMaskMatrix = zeros(1,7);
        else %if the mat file exists, then load it  
            disp('Start Mat Load'); 
            Ctemp = load('CropMaskMatrix.mat','CropMaskMatrix');
            CropMaskMatrix = Ctemp(1).CropMaskMatrix;
            disp('Done Mat Load');
        end
        %in matrix, check whether the entry exists
        if isempty(find(CropMaskMatrix(:,1) == str2double(position), 1)) == 0 %if pos in matrix
            Mrow = find(CropMaskMatrix(:,1) == str2double(position));
        else %if pos is not in matrix
            if CropMaskMatrix(1,1) == 0
                Mrow = 1;
            else
                Mrow = length(CropMaskMatrix(:,1)) + 1;
            end
        end
        %then either replace old entry, or make new entry
        CropMaskMatrix(Mrow,1) = str2double(position);
        cropRange = str2num(get(heditFR,'String')); CropMaskMatrix(Mrow,2) = cropRange(1);
        CropMaskMatrix(Mrow,3) = cropRange(2);
        CropMaskMatrix(Mrow,4) = row(1)-1; %i.e. tmargin
        CropMaskMatrix(Mrow,5) = col(1)-1; %i.e. lmargin
        CropMaskMatrix(Mrow,6) = 1040-row(2); %i.e. bmargin
        CropMaskMatrix(Mrow,7) = 1392-col(2); %i.e. rmargin
        
        %save matrix to mat file, and remove variable from workspace
        save('CropMaskMatrix.mat','CropMaskMatrix'); %v6 avoid compression...makes everything faster
        clear('CropMaskMatrix'); clear('Ctemp');
        disp(['Clicky saved for position ' position]);
    end

    function playRectbutton_Callback(~,~)
       sizenewMov = size(newMov);
       looplength = sizenewMov(3);
       for counter = 1:max(str2num(get(heditFR,'String')))
          if channel == 't'
              imshow(newMov(:,:,counter),[180 700]); 
          else
              imshow(newMov(:,:,counter),[]); 
          end
          pause(.000001);
       end                 
       current_frame = total_frames;
    end

    function clicky_Callback(~,~)
       [col,row] = ginput(2);
       col = round(col);
       row = round(row);
       
       sizeMov = size(Mov);
       W = 7; %width of lines
       Rect = zeros(1040,1392,sizeMov(3),'uint16');
       Rect(row(1):row(1)+W,col(1):col(2),:) = 9000; %top horizontal bar
       Rect(row(2):row(2)+W,col(1):col(2),:) = 9000; %bottom horizontal bar
       Rect(row(1):row(2),col(1):col(1)+W,:) = 9000; %left veritcal bar
       Rect(row(1):row(2),col(2):col(2)+W,:) = 9000; %right veritcal bar
       %add Rect to Mov
       newMov = imadd(Mov,Rect);        
    end

    function back_Callback(~,~)
        prev_frame = mod(current_frame-2,total_frames)+1;
        if channel == 't'
            imshow(newMov(:,:,prev_frame),[180 700]); 
        else
            imshow(newMov(:,:,prev_frame),[]); 
        end
        current_frame = prev_frame;
        set(htext,'String',['Frame ' num2str(current_frame) ' of ' num2str(total_frames)]);         
    end
    
    function forward_Callback(~,~)
        next_frame = mod(current_frame,total_frames)+1;
        if channel == 't'
            imshow(newMov(:,:,next_frame),[180 700]); 
        else
            imshow(newMov(:,:,next_frame),[]); 
        end
        current_frame = next_frame;
        set(htext,'String',['Frame ' num2str(current_frame) ' of ' num2str(total_frames)]);         
    end

    function playloadedbutton_Callback(~,~)
       sizeMov = size(Mov);
       %set(htext,'String',[num2str(sizeMov(1)) ' ' num2str(sizeMov(2)) ' ' num2str(sizeMov(3))]);
       looplength = sizeMov(3);
       for counter = 1:looplength
           if channel == 't'
                imshow(Mov(:,:,counter),[180 700]);
           else
                imshow(Mov(:,:,counter),[]);    
           end
           pause(.00001);                  
       end
       current_frame = looplength;   
    end

    function getframes_Callback(~,~)
       position = get(hedit,'String');
       set(htext,'String','Started dir command'); pause(.00001);       
       tempdir = dir([basename '-' position '-' channel '-*']);
       img1 = imread(tempdir(1).name);
       imgsize = size(img1);
       Mov = zeros(imgsize(1),imgsize(2),length(tempdir),'uint16');
       set(htext,'String','Just made Directory');pause(.00001);
       tic;
       
       %now loading images into Mov
       Mov(:,:,1) = img1;
       looplength = length(tempdir);
       for counter = 2:looplength
          imgname = tempdir(counter).name;
          Mov(:,:,counter) = imread(imgname,'tif'); 
          set(htext,'String',['Frame ' num2str(counter) ' of ' num2str(looplength) ' loaded']);  pause(.00001);          
          imshow(Mov(:,:,counter),[]); 
       end
       readintime = toc;
       newMov = Mov;
       current_frame = looplength;
       total_frames = looplength;
       set(htext,'String',['Reading in frames took ' num2str(readintime)]);
       set(heditFR,'String',['1 ' num2str(looplength)]);
    end

    function getNextPosframes_Callback(~,~)
       position = str2(str2double(get(hedit,'String'))+1);
       set(hedit,'String',position);       
       set(htext,'String','Started dir command'); pause(.00001);       
       tempdir = dir([basename '-' position '-' channel '-*']);
       img1 = imread(tempdir(1).name);
       imgsize = size(img1);
       Mov = zeros(imgsize(1),imgsize(2),length(tempdir),'uint16');
       set(htext,'String','Just made Directory');pause(.00001);
       tic;
       
       %now loading images into Mov
       Mov(:,:,1) = img1;
       looplength = length(tempdir);
       for counter = 2:looplength
          imgname = tempdir(counter).name;
          Mov(:,:,counter) = imread(imgname,'tif'); 
          set(htext,'String',['Frame ' num2str(counter) ' of ' num2str(looplength) ' loaded']);  pause(.00001);          
          imshow(Mov(:,:,counter),[]); 
       end
       readintime = toc;
       newMov = Mov;
       current_frame = looplength;
       total_frames = looplength;
       set(htext,'String',['Reading in frames took ' num2str(readintime)]);
       set(heditFR,'String',['1 ' num2str(looplength)]);
    end

    function popup_menu_Callback(source,~)
       str = get(source,'String');
       val = get(source,'Value');
       switch str{val}
           case 'Phase' 
               channel = 'p';
           case 'RFP'
               channel = 't';
           case 'YFP'
               channel = 'y';
           case 'CFP'
               channel = 'c';
       end       
    end

    function CurrFrameAsLastCropFrame_Callback(~,~)
       set(heditFR,'String',['1 ' str2(current_frame)]);
    end
end


function y = str2(x)
    y = num2str(x,'%1.2d');
end

function y = str3(x) %#ok<DEFNU>
    y = num2str(x,'%5.3d');
end



