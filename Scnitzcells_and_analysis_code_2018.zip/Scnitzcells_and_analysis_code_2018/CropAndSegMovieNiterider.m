

%% User Settings
%cd into directory of interest!
datestr = '2013-05-23'; %set as string in YYYY-MM-DD format
poslist = [2     7    10    13    15    16    21    27    28    29    32    39    45    49    52]; %position number, set as number(or vector of numbers), not as string
imgdir = 'C:\JinData\2013-05-23-delUXsigW\sub'; %no slash at end
    %no slash at end, put in the folder that will contain the cropped
    %images, e.g. the sub folder
    %avoid spaces in imgdir

%% Applying Crop to Images...you must have used MovieCropGui2 first
ApplyCropMaskMatrix; %careful! this script may have its own clear all
                     %also! set the channels to be cropped in the script
    
    
%% Running Segmentation on Movies
%Finding basename
basenamedir = dir([imgdir filesep '*-*-y-001.tif']);
basenamesetpoints = strfind(basenamedir(1).name,'-');
basename = basenamedir(1).name(1:basenamesetpoints(1)-1);  

%now running through movies and segmenting each one
for posctr = 1:length(poslist)
    pos = poslist(posctr);
    p = initschnitz([basename '-' num2str(pos,'%1.2d') '_1'],...
        datestr,...
        'bacillus',...
        'rootDir',imgdir,...
        'imageDir',imgdir);
    p = segmoviefluorjonlimit(p); %found in \\thecusaur\sigb\randomshare
end

%% Cropping the Seg Files
CropSegFilesNiterider; %make sure no settings are changed in this script!

