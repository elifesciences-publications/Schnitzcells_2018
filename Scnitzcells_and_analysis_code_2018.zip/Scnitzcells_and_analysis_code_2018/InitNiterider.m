

%% User Settings
clear all; close all; clc;
mypos = 5; %position number, set as number, not as string
imgdir = 'I:\Data\new_dotps_test\2013-05-22-sigLyfp-SELECTED\sub';
    %no slash at end, put in the 'sub' folder...specifically 1 folder above date folder
    

%% Initializing 'p' structure
% Finding datestr
D = dir([imgdir filesep '201*-*-*']); D = D(vertcat(D.isdir));
if length(D) ~= 1
    error('Either a date directory was not found in the sub folder, or there was more than 1 identified date folder');
end
datestr = D(1).name; 
clear D;

%finding basename
basename = 'acdc';

%now initializing p
p = initschnitz([basename '-' num2str(mypos,'%1.2d') '_1'],...
    datestr,...
    'bacillus',...
    'rootDir',imgdir,...
    'imageDir',imgdir);

clear basenamedir basenamesetpoints;

clear basename datestr imgdir mypos;
    
%% below code here for convenience
close all; p = manualcheckseg(p,'override',1); close all;
