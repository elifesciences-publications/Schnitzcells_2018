% Note if your movie has an underscore in it you are fucked
% delete('*_thumb_*');
% delete('*[None]*');

%Setting initial conditions
clear all;
% profile off
% profile clear
% profile on -detail builtin
D = dir('*_*');
D([D.isdir]) = []; %removing directories


%Running loop for Renaming Files
looplength = length(D);
for j = 1 : looplength
    %Determining what the new filename will be, based on the old filename
    setpoints = strfind(D(j).name,'_');
    name = D(j).name(1:setpoints(1)-1);
    channel = D(j).name(setpoints(1)+1:setpoints(2)-1);
    stagepos = D(j).name(setpoints(2)+2:setpoints(3)-1);
    timepoint = D(j).name(setpoints(3)+2:end-4);
    if isempty((strfind(channel,'Alex'))) == 0
        newchannel = 't';
    elseif isempty((strfind(channel,'RFP'))) == 0
        newchannel = 't';
    elseif isempty((strfind(channel,'CFP'))) == 0
        newchannel = 'c';
    elseif isempty((strfind(channel,'rightfield'))) == 0
        newchannel = 'p';
    elseif isempty((strfind(channel,'Phase'))) == 0
        newchannel = 'p';
    elseif isempty((strfind(channel,'YFP'))) == 0
        newchannel = 'y';
    end
    newname = [name,'-',str2(str2double(stagepos)),'-',newchannel,'-',str3(str2double(timepoint)),'.tif'];
   
    %Renaming the File with the new filename found above
    %movefile(D(j).name,newname); %this is the old code
    oldname = D(j).name;
    A = java.io.File(oldname);
    A.renameTo(java.io.File(newname)); 

    disp([num2str(j) '  of ' num2str(looplength)]); %displaying progress
end
% profile off
% profile viewer

