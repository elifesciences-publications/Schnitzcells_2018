



%% User Settings 
mydir = 'C:\Documents and Settings\Nikon2\Desktop\sample_movie\'; %w/ backslash, please



%% Viewer
% find total # of positions
% dirlist = dir([basename '*.tif']); dirlist = {dirlist.name};
% poslist = cellfun(@(x) str2num(x),unique(cellfun(@(x) x(min(findstr(dirlist{1},'-'))+1:min(findstr(dirlist{1},'-'))+2),dirlist,'uniformoutput',false)));


% basename = 'acdc';
% poslist = 1:52;
% testfr = 62;
% 
% close all; figure;
% for ctr = poslist
%    b = imread([mydir basename '-' num2str(ctr,'%1.2d') '-t-' num2str(testfr,'%5.3d') '.tif']);
%    imshow(b,[]);
%    pause;   
% end









%% Remove Positions
% deleteList = [4 5 6 10:12];  
% for ctr = 1:length(deleteList)
%     delete([mydir '*-' num2str(deleteList(ctr),'%1.2d') '-*.tif']);
%     disp(ctr);
% end

%% Remove Frames
deleteList = 41:73;
for ctr = 1:length(deleteList)
    delete([mydir '*-' num2str(deleteList(ctr),'%5.3d') '.tif']);
    disp(ctr);
end

