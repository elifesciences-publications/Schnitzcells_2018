

% Uses the sigXXX-XXX-y.tif filename convention
% Call as : redsegAutomatic
%
%
%
% History:
%
% 2014May05: Made some minor changes, e.g. commented some unnecessary lines.
%            Nothing major.
%
% This redseg was copied from \\Thecusaur\sigb\RandomShare on Fri 5/18/2012.
% The only modification is the user does not choose which images get
% segmented; instead, all images get segmented.
%
% 2015Feb11: Set 'naturalback' to 1 in code





function redsegAutomatic(varargin)

%Default values for parameters.
%Useflat specifies whether you have background corrected files.
%Naturalback
useflat = 0;

%Assumes first image saved in series starts on 1 (eg 'mytif-01-p.tif)
firstimnum = 1;

%In case images are taken not through Michael's program.
%screw it, I don't think we need it
% defaultctimestr = '1';
% defaultcgainstr = 'med';
% defaultcexptime = 1;

%implement quickreg or fixed shift as an option here
%Each row represents registration for separate channel
shift = zeros(5,2); %No registration

global doreg %Currently we have no clue what this does

%Going through user arguments
for i = 1:length(varargin),
    theparam = lower(varargin{i});
    switch(strtok(theparam)),
        case 'flat',
            disp('flatfield turned on');
            useflat = 1;
        case 'naturalback',
            naturalback = 1;
            disp('natural backgrounds');
    end;
end

naturalback = 1;
colorcode = 'cygrx'; %All possible colors, notably 't' from Olympus scopes is not included - YET
Ncolors = length(colorcode); %Ncolors is used later
shift = zeros(5,2); %Used for image registration later (see fx imshift)

% This is a setting which changes how images are displayed.
iptsetpref('imshowborder','tight');
erodesize = 5;
if exist('qual'),
    qualfunc = @qual; %Used in fx collectstats
else
    qualfunc = [];
end;

%suffix is used during saving
% suffix = input(['choose your suffix [default = -1]'],'s');
% if isempty(suffix),
    suffix = '-1';
% end;

prefixes = findprefixes; %prefixes is an array of filename strings

%User specifes which prefixes to segment here
for i = 1:length(prefixes),
%     x = input(['do you want to do this one: [Y/n] ',char(prefixes(i))],'s');
%     if isempty(x),
%         x = 'Y';
%     end;
%     if upper(x) == 'N',
%         doit(i) = 0;
%     else
%         doit(i) = 1;
%     end;
    doit(i) = 1;
end;
prefixes = prefixes(logical(doit));
prefixes

ucolors = [];
colorused = zeros(Ncolors,1);

%Specifies which channels are present in snapshots
for i = 1:Ncolors,
    D = dir(['*-',colorcode(i),'.tif']);
    if length(D)>0,
        ucolors = cat(2,ucolors, colorcode(i));
        colorused(i) = 1;
    end;
end;
ucolors,

%Allows for user flatfield and background substraction
%'flat' is a user created fit (eg parabola) of image flatness in each channel
%eg flat-y.tif
%'flatback' is a empty image in each channel (no cells)
if useflat,
    flat = [];
    for i = 1:length(ucolors),
        flatname = ['flat-',ucolors(i),'.tif'];
        if exist(flatname),
            flat = imread(flatname);
        else
            disp(['can''t find ',flatname,'...quitting']);
        end;
        flatbackname = ['flatback-',ucolors(i),'.tif'];
        if exist(flatbackname),
            flatbac = imread(flatbackname);
        else
            disp(['can''t find ',flatbackname,'...quitting']);
        end;
        flat = imsubtract(flat,flatback);
        myflat{i} = double(medfilt2(flat,[5 5]));
    end;
end;



%Giant for loop
for p = 1:length(prefixes),
    L=[];
    myname = char(prefixes(p));
    mynamesimple = myname;
    mynamesimple(find(mynamesimple=='-'))=[];
    mynamesimple(find(mynamesimple==' '))=[];
    mynamesimple(find(mynamesimple=='+'))=[];
    mynamesimple(find(mynamesimple=='='))=[];
    mynamesimple(find(mynamesimple=='.'))=[];
    
    D = dir([mynamesimple ,'-*-r.tif']);
    %Below loop filters rfp filenames based on filename length
    for i = 1:length(D),
        L(i) = length(char(D(i).name));
    end;
    %     We live on the edge
    L0 = length(mynamesimple)+10;
    D = D(find(L==L0));

    uucolors = [];
    %Checking file integrity of saved files, again.
    for i = 1:length(ucolors)
        D1 = D(1).name;
        f = findstr(D1,'-r.tif');
        D1(f(1)+1) = ucolors(i);
        if exist(D1),
            uucolors = cat(2,uucolors,ucolors(i));
            disp(['using color ',ucolors(i)]);
        end
    end

    %screw this section of code, I don't think we need it
    %exptime = [];
    %for i = 1:length(uucolors),
        %[Timestr,Gainstr,Exptime,Cube] = imsettings(D(1).name,uucolors(i));
        %if isempty(Timestr),
            %disp('using default values for c...')
            %Timestr = defaultctimestr;
            %Gainstr = defaultcgainstr;
            %Exptime = defaultcexptime;
        %end;
    %end

    disp(['Starting ',myname]); %Displays which prefix is currently running
    Nimgs = length(D);
    S = [];

    %Adding leading zeros to image numbers.
    for i = 1:Nimgs,
        disp(['Working on Prefix ' num2str(p) ' of ' num2str(length(prefixes)) '   img ' ...
            num2str(i) ' of ' num2str(Nimgs)]);
        imgno = findstr('-r',D(i).name);
        xxx = D(i).name(imgno-3:imgno-1);
        pname = ['',myname,'-',xxx,'-r.tif'];

        if exist(pname),
            imp = imread(pname);
            psize = size(imp);
            d = dir(['',myname,'-',xxx,'-r.tif']);
            %             [dstr,tstr,dn] = imdatetime(pname); %CHECK:  Do we really need imdatetime? [Jon]
            imf = [];
            ph3 = imp;

            %Rescales image values to the 25th biggest value, maybe not
            %necesary
            for i= 1:size(ph3,3),
                ph3 = ph3;
                ph3(:,:,i)= medfilt2(ph3(:,:,i),[3 3]);
                x= double(ph3(:,:,i));
                s= sort(x(:));
                small= s(25);
                %ALT CODE:  Subtract the background prior to rescaling
                small1000 = s(1000);
                ph3(ph3<small1000)=0;
                big= s(end-25);
                rescaled=(x - small)/(big - small);
                rescaled(rescaled<0)= 0;
                if max(max(ph3)) > 400 %Looking for empty images
                    ph3(:,:,i)= uint16(10000*rescaled);
                else
                    %ph3 = 0;
                end
            end;

            for j = 1:length(uucolors),
                f = find(colorcode==uucolors(j));

                %Registers each channel image before reading it in as 'im'
                im = double(imshift(imread(['',myname,'-',xxx,'-',uucolors(j),'.tif']),shift(f,:)));
                im = imresize(im,psize,'bilinear');
                if useflat,
                    imf{j} = im./myflat{j};
                else
                    imf{j} = im;
                end;
            end;

            T = progthreshfluor(ph3); %Main segmentation function
            T = imclearborder(T,4); %Removes cells near border

            %Smooth cell edges by eroding and dilating
            t1= imerode(T, strel('disk',4));
            t2= bwlabel(t1);
            L= imdilate(t2, strel('disk', 4));

            %Goes through and collects cell data and stores it into structure 's'.
            [s,Lq,Lo] = collectstats(imf,L,qualfunc);

            %Makes colormap image and displays it
            try
                imagesc(makergb(T,Lq,imp));
                drawnow;
            catch
            end
            %Draws a box around each cell in image and takes a low value to
            %stores in background value (b.val) in the 's' structure.
            if ~isempty(s),

                eval(['Lq',mynamesimple,'',xxx,'=Lq;']);
                if naturalback,
                    for i = 1:length(s),
                        lowbox = floor(max([ones(1,2); s(i).Centroid - 64]));
                        highbox = floor(min([size(imp'); s(i).Centroid + 64]));
                        for kk = 1:length(imf),
                            box = imf{kk}(lowbox(2):highbox(2),lowbox(1):highbox(1));
                            sbox = sort(box(:));
                            bval = sbox(floor(length(sbox)*.005));
                            s(i).bval(kk) = bval;
                        end;
                    end;
                end;

                if isempty(S),
                    S = s;
                    %			eval(['S = s',mynamesimple,'',xx,';']);
                else
                    %			eval(['S = cat(2,S,s',mynamesimple,'',xx,');']);
                    S = cat(2,S,s);
                end;
            end;
        else
            disp(['skipping ',pname]);
        end;
    end;


    %Saving single 'S' files.
    eval(['S',mynamesimple,'=S;']);
    if ~isempty(S),
        eval(['save S',mynamesimple,suffix,' S',mynamesimple,' Lq',mynamesimple,'*']);
    else
        eval(['save S',mynamesimple,suffix]);
    end;
    eval(['clear S',mynamesimple,' Lq',mynamesimple,'*']);
end;

% finally, create the S file, if specified:

clear S*;
D = dir(['S*',suffix,'.mat']);
for i = 1:length(D), load(D(i).name,'S*'); end;
save('sfile.mat','S*','-v6');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SUBFUNCTIONS BELOW
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%--------------------------------------------------------------------------
% This is the key function here.
%--------------------------------------------------------------------------
function progfluor = progthreshfluor(imt)
p = []; %Initialize p

%Parameters below influence segmentation
p.edge_lapofgauss_sigma = 3;
p.minCellArea = 50;
p.minCellLengthConservative= 12; % JCR observed 2005-02-16
p.minCellLength = 20;            % JCR observed 2005-02-16
p.maxCellWidth = 20;             % JCR observed 2005-02-16
p.minNumEdgePixels = 215;        % ME set to 215 in mail to JCR 2005-08-18
p.maxThreshCut = 0.3;
p.maxThreshCut2 = 0.2;
p.maxThresh = 0.1;
p.minThresh = 0.1;
p.imNumber1 = 2;
p.imNumber2 = 1;
p.radius = 5;
p.angThresh = 2.7;

imt = imt - 1200; %Subtract the bottom 1.2% of image
e = edge(imt,'log',0);
f = imfill(e,'holes');
L = bwlabel(f);

%Find and kill small cells
r = regionprops(L,'Area');
flittle = find([r.Area]<50);
disp(['Removing small (crud) cells(', num2str(length(flittle)),').']);
goodones = setdiff(1:max(max(L)), flittle);
bw2 = ismember(L, goodones);
L2 = bwlabel(bw2);
% L2= renumberimage(L2); %Remove for speed?

%Find cells with good Solidity
r2 = regionprops(L2,'Solidity');
fsolid = find([r2.Solidity]>0.2);
bw3 = ismember(L2,fsolid);
L3 = bwlabel(bw3);

%Remove short cells
r= regionprops(L3,'majoraxislength');
fshort= find([r.MajorAxisLength] < p.minCellLengthConservative);
disp(['Removing short cells(', num2str(length(fshort)),').']);
longones = setdiff(1:max(max(L3)), fshort);
bw4 = ismember(L3, longones);
L4 = bwlabel(bw4);

%Remove unfilled cells on edge
r= regionprops(L4, 'area');
fpts= find([r.Area]<200);
edgy = setdiff(1:max(max(L4)), fpts);
bw5 = ismember(L4, edgy);
L5= bwlabel(bw5);

L6= L5;
L7=L6;
label = max2(L7);

% BREAKING UP BIG CELLS
% Goes along the THINned cell and looks for places where there is a change
% in the fluor value - i.e. where there could be a space between cells.
r= regionprops(L6, 'majoraxislength');
fbiggies= find(([r.MajorAxisLength]>50));
disp(['Breaking up big cells(', num2str(length(fbiggies)),').']);
for i = 1:length(fbiggies),
    Lcell= +(L6 == fbiggies(i)); % + converts logical to double
    Lcell(Lcell == 1)= fbiggies(i);
    [cutcell, num]= breakcellfluorsnaps(Lcell, imt(:,:,1), ...
        p.maxThresh, p.minThresh, p.minCellLength);
    L7(L6 == fbiggies(i))= 0;
    % place cutcell
    label= label+length(fbiggies); %max2(L7);
    for j = 1:num,
        L7(cutcell==j)= label+j;
    end;
end;
L7= renumberimage(L7);

% DEKINKING CELLS with low solidity
% Tries again to look for phase extrema along the thin, using another phase
% slice (if available). Then uses "dekinker" to look for sharp angles along
% the bacterial spine (thin) - if those are found, the cell is cut at the
% corner.
% uses PHSUB(:,:,p.imNumber2) (default p.imNumber2=1)
L8= L7;
r= regionprops(L7, 'solidity');
fkinkies= find(([r.Solidity] < 0.85));
disp(['Breaking kinky cells(',num2str(length(fkinkies)),').']);
label = max2(L8);
for i = 1:length(fkinkies)
    %disp([' ',num2str(i),': dekinking cell number ',num2str(fkinkies(i))]);
    Lcell= +(L7 == fkinkies(i)); % + converts logical to double
    Lcell(Lcell == 1)= fkinkies(i);

    [cutcell, num] = breakcellfluorsnaps(Lcell, imt(:,:,1), ...
        p.maxThresh, p.minThresh, p.minCellLength);
    if num == 1
        cutcell= dekinker(Lcell, p.radius, p.minCellLength, p.angThresh);
    end;

    L8(L7 == fkinkies(i))= 0;
    % place cutcell
    for j = 1:num,
        L8(cutcell==j)= label+length(fkinkies);
    end;
end;

L8= renumberimage(L8);

% FINAL IMAGE
disp('Almost done.');

%Final check for small cells:  probably useless
r= regionprops(L8, 'area');
flittles= find([r.Area] < p.minCellArea);
for i= 1:length(flittles),
    % delete cell
    L8(L8 == flittles(i))= 0;
end;
%L8= renumberimage(L8);

%Plump the cells for final mask
L9= carefuldilate(+L8, strel('diamond',1), 1);
progfluor = L9;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End Progthreshfluor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [mystats,Lq,Lo] = collectstats(fimgs,L,qualfunc)

if nargin >=3,
    if ~isempty(qualfunc),
        ourqualfunc = qualfunc;
    else
        ourqualfunc = @qual;
    end;
else
    ourqualfunc = @qual;
end;

sz = size(L);
Lo = L;
n = max(max(L)); % num objects

if n>0,
    stats = regionprops(L,'MinorAxisLength','MajorAxisLength','Eccentricity','Area','Centroid','ConvexArea','EulerNumber','Solidity');
    qualifies = feval(ourqualfunc,stats); %No clue what this is doing
    Lq = zeros(size(L));
else
    disp(['no cells found on this img']);
    qualifies = [];
    Lq = [];
    mystats = [];
    return;
end;

%register the images with cells
if(sum(qualifies))
    for i=1:length(fimgs)
        %resize the fluors if binned
        fimgs{i} = imresize(fimgs{i},sz,'bilinear');
        [subreg,shift,back]=regsnaps(L(100:424,100:424),fimgs{i},[100 100 424 424],3);
        fimgs{i}=imshift(fimgs{i},-shift);
        disp(['shift' num2str(i) ' = ' num2str(shift(1)) ' ' num2str(shift(2))]);
    end
end

k = 1;
for i = 1:n,
    if qualifies(i)
        Lq(find(Lo==i))=i;

        ff = find(L==i);

        for cnum = 1:length(fimgs),
            fimg = fimgs(cnum);
            fimg = fimg{1};
            newstruc.mean(cnum) = mean(fimg(ff));
            newstruc.max(cnum) = max(fimg(ff));
            newstruc.min(cnum) = min(fimg(ff));
            newstruc.median(cnum) = median(double(fimg(ff)));
            newstruc.total(cnum) = sum(fimg(ff));
            newstruc.std(cnum) = std(fimg(ff));
            s = sort(fimg(ff));
            %             newstruc.melowmeas(cnum) = mean(s(end-2:-1:end-9));

        end;

        %newstruc(k).stats = stats(i);
        % copy stats:
        statfields = fieldnames(stats(i));
        for g = 1:length(statfields),
            fn = char(statfields(g));
            fv = getfield(stats(i),fn);
            newstruc = setfield(newstruc,fn,fv);
        end;

        mystats(k) = newstruc;

        k = k + 1;
    end;
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xsubreg, xshift, xback] = regsnaps(L, imx, rect, deltamax)
% function [xsubreg, xshift, xback] = regsnaps(L, imx, rect, deltamax)
%  calculates translation between phase and fluorescent images
% load images if necessary
if min(size(imx))==1,
    if isempty(findstr('.tif', imx)),
        imx = [imx,'.tif'];
    end;
    if exist(imx)==2
        imx= imread(imx);
    end
end
if min(size(imx))>1
    % get subimages
    imx1= double(imx(rect(1):rect(3), rect(2):rect(4)));
    LL= +(L(1+deltamax:end-deltamax, 1+deltamax:end-deltamax) > 0);
    % try all possible translations
    for di= -deltamax:deltamax,
        for dj= -deltamax:deltamax,
            imx2= imx1(deltamax+di+1:end-deltamax+di, deltamax+dj+1:end-deltamax+dj);
            xsum(di+deltamax+1,dj+deltamax+1)= sum(imx2(LL > 0));
        end;
    end;
    % best translation is the one with largest csum (the most white pixels in LL)
    [xbesti, xbestj]= find(xsum == max2(xsum));
    xbesti= xbesti - deltamax - 1;
    xbestj= xbestj - deltamax - 1;
    % record translation
    xshift= [xbesti(1) xbestj(1)];
    % record translated images
    xsubreg= imx((rect(1):rect(3))+xbesti(1), (rect(2):rect(4))+xbestj(1));
    % calculate background fluorescence
    imxb = double(imx);
    imxb(rect(1):rect(3), rect(2):rect(4))=0;
    imxbvect=imxb(imxb>0);
    xback=median(imxbvect);
else
    xsubreg=[];
    xshift=[];
    xback=[];
end;

%%%%%%%%%%%%%%%%%% End Regsnaps

%--------------------------------------------------------------------------
% This function is related to displaying the images as the segmentation
% code runs.
%--------------------------------------------------------------------------
function rgb = makergb(r,g,b);

if nargin<2,
    disp('MelowError: I need at least 2 images here!');
    return;
end;

if size(r,1) == 1,
    % these must be filenames;
    r = imread(r);
    g = imread(g);
    if nargin>=3,
        b = imread(b);
    end;
end;

if nargin==2,
    b = r;
    b(:) = 0;
end;

r = double(r(:,:,1,1));
g = double(g(:,:,1,1));
b = double(b(:,:,1,1));

rgb(:,:,1) = (r-minmin(r)) / (maxmax(r)-minmin(r));
rgb(:,:,2) = (g-minmin(g)) / (maxmax(g)-minmin(g));
rgb(:,:,3) = (b-minmin(b)) / (maxmax(b)-minmin(b));

rgb(isnan(rgb)) = 0;
rgb = uint8(rgb * 255);
%--------------------------------------------------------------------------
%makergb ends here.
%--------------------------------------------------------------------------

function y = imshift(x,shift)
y = x;
y(:,:,:,:) = minmin(y);

% first shift x:
shx = shift(1);
if shx>0,
    y(1+shx:end,:,:,:) = x(1:end-shx,:,:,:);
elseif shx<0,
    shx = abs(shx);
    y(1:end-shx,:,:,:) = x(1+shx:end,:,:,:);
end;

% then shift y:
shy = shift(2);
if shx~=0,
    x = y;
end;
if shy>0,
    y(:,1+shy:end,:,:) = x(:,1:end-shy,:,:);
elseif shy<0,
    shy = abs(shy);
    y(:,1:end-shy,:,:) = x(:,1+shy:end,:,:);
end;

if max(abs(shift))==0,
    y = x;
end;

%Qualifies each cell in an image for data gathering
function b = qual(stats)
if isempty(stats),
    b = [];
else
    b = ones(length(stats),1);
end;

%--------------------------------------------------------------------------
% The function 'imsettings' starts...
%--------------------------------------------------------------------------
function [exptimestr, gainstr,exptime,cube] = imsettings(pname, color)

pos = findstr('-p', pname);
pname(pos+1) = color;
pname,

if exist(pname),

    iminfo = imfinfo(pname);

    if isfield(iminfo,'ImageDescription'),

        descrip = iminfo.ImageDescription
    else
        descrip = [];
    end;
else
    exptimestr = '';
    gainstr = '';
    exptime = 0;
    cube=-1;
    return;
end;

if isempty(descrip),
    exptimestr = '';
    gainstr = '';
    exptime = 0;
    cube=-1;
    return;
end;


exptimepos = findstr('Exptime=',descrip) + length('Exptime=');
exptime = sscanf(descrip(exptimepos:end),'%f');
exptimestr = num2str(exptime);
cubestrpos = findstr('Cube=',descrip) + length('Cube=');
cube = sscanf(descrip(cubestrpos:end),'%d');

exptimestr(exptimestr=='.')=[];

gainpos = findstr('Gain=',descrip) + length('Gain=');
gain = sscanf(descrip(gainpos:end), '%f');
switch(gain),
    case 1,
        gainstr = 'low';
    case 2,
        gainstr = 'med';
    case 3,
        gainstr = 'high';
    otherwise,
        disp('can''t find gain setting -- using high');
        gainstr = 'high';
end;
%--------------------------------------------------------------------------
% ... and ends.
%--------------------------------------------------------------------------


%--------------------------------------------------------------------------
% The function 'breakcellfluorsnaps' starts...
%--------------------------------------------------------------------------


function [cutcell, ncut] = breakcellfluorsnaps(cell, phcell, maxthresh, minthresh, mincelllength, figs, thinx, thiny)
% function cutcell= breakcell(cell, phcell, maxthresh, minthresh, mincelllength, figs, thinx, thiny)
%
% breaks an individual cell by running a box along the `thin' of cell
% cell is cut at points where there is a minimum in the segmented image (cell)
%  or a maximum in the phase image (phcell)
% maxthresh & minthresh:    threshold values (smaller they are the more cuts are included)
% mincelllength:    cuts which create cells smaller than this will be ignored
%
% rather than calculate thin from cell, can receive coordinates of thin via (thinx, thiny)

if nargin == 5
    figs= 0; % figs= 1 for graphical output (debug mode)
end;
maxdist= 4; % distance from pt used to test if it is a maximum
mindist= 4; % distance from pt used to test if it is a minimum
diffthresh= 3; % size of jump in diff of minpts or maxpts

% make sure image is black and white and not logical
% cellno= max2(cell); %This was commented out for speed. 06/05/08
cell= +(cell > 0);
phcell= +phcell;

% % check Euler Number
% if nargin < 7
%     r= regionprops(cell, 'eulernumber');
%     if [r.EulerNumber] ~= 1
% %         if figs==1
%             disp(['Circular region in thin. Euler Number= ',num2str([r.EulerNumber])]);
% %         end;
%         cutcell= bwlabel(cell, 4);
%         return;
%     end;
% end;

% extract subimages
[fx, fy]= find(cell);
extra= 5;
xmin= max(min(fx) - extra, 1);
xmax= min(max(fx) + extra, size(cell,1));
ymin= max(min(fy) - extra, 1);
ymax= min(max(fy) + extra, size(cell,2));
subcell= cell(xmin:xmax, ymin:ymax);
originalsubcell= subcell;
subphcell= phcell(xmin:xmax, ymin:ymax);


% FIND THIN (CENTRE LINE) OF CELL

if nargin < 7
   
    % make thin of image
    thin= bwmorphmelow(subcell, 'thin', inf);
    % clean up thin (remove spurious spurs)
    thin= bwmorphmelow(bwmorphmelow(thin, 'diag', 1), 'thin', inf);
   
    % find spur points
    spurs= thin & ~bwmorphmelow(thin, 'spur', 1);
    [sx, sy]= find(spurs > 0);
    if figs == 1
        disp(['No of spur points in thin= ',num2str(length(sx))]);
    end;
    if length(sx) > 2
        for i= 2:length(sx)
            subcell2= zeros(size(subcell));
            subcell2(sx(1), sy(1))= 1;
            subcell2(sx(i), sy(i))= 1;
            subcell2= imdilate(subcell2, strel('disk', 2));
            subcell3= subcell2 | thin;
            subcell4= bwmorphmelow(subcell3, 'spur', inf);
            subcell5= bwmorphmelow(subcell4, 'thin', inf);
            subcellthin{i-1}= bwmorphmelow(subcell5, 'spur', 2);
        end;
    else
        subcellthin{1}= thin;
    end;
   
else
   
    % create thin image
    thin= zeros(size(subcell));
    fx= thinx - xmin + 1;
    fy= thiny - ymin + 1;
    for i= 1:length(fx)
        thin(fx(i), fy(i))= 1;
    end;
    subcellthin{1}= thin;
   
    % find spur points
    spurs= thin & ~bwmorphmelow(thin, 'spur', 1);
    [sx, sy]= find(spurs > 0);
    if length(sx) ~= 2
        disp('Given thin has multiple spur points.');
        cutcell= cell;
        return;
    end;
   
end;

% RUN THROUGH EACH THIN TO FIND POINTS TO CUT
for k= 1:length(sx)-1
    % obtain points ordered along thin of image
    clear avp avs;
    if nargin < 7
        [fx, fy]= walkthin(subcellthin{k});
        if isempty(fx)
            continue;
        end;
    end;
    j= 1;
    for bsize= 2:5
        for i= 1:length(fx),
            % extract mean of pixels in phase image lying in box bsize
            axmin= max(1, fx(i) - bsize);
            axmax= min(size(subcell,1), fx(i) + bsize);
            aymin= max(1, fy(i) - bsize);
            aymax= min(size(subcell,2), fy(i) + bsize);
            avp(j,i)= mean2(subphcell(axmin:axmax, aymin:aymax));
            avs(j,i)= mean2(originalsubcell(axmin:axmax, aymin:aymax));
        end;
        j= j+1;
    end;
    % normalize
    avs= mean(avs)/median(median(avs));
    avp= mean(avp)/median(median(avp));
   
   
    % find local maxima in phase (potential points to be cut)
    maxpts= [];
   
    %Altered to find local minima for fluor segmentation code jan28th08
%     for i= 1 + maxdist:length(avp) - maxdist
%         if (avp(i - maxdist) < avp(i)) & (avp(i + maxdist) < avp(i))
%             maxpts= [maxpts i];
%         end;
%     end;
      for i= 1 + maxdist:length(avp) - maxdist
        if (avp(i - maxdist) > avp(i)) & (avp(i + maxdist) > avp(i))
            maxpts= [maxpts i];
        end;
    end;
    if ~isempty(maxpts)
        % maxpts contains multiple points for each maximum
        % find boundaries between sets of points
        maxboundaries= unique([1 find(diff(maxpts) > diffthresh) length(maxpts)]);
        if length(maxpts) == 1
            maxs{k}= maxpts;
            % measure steepness of maximum
            maxsc{k}= mean([avp(maxs{k}-maxdist) - avp(maxs{k}),...
                    avp(maxs{k}+maxdist) - avp(maxs{k})]);
                             
        else
            % each maximum is the average of each set of points associated with it
            for i= 2:length(maxboundaries)
                submaxpts= maxpts(maxboundaries(i-1) + 1:maxboundaries(i));
                [av2m, av2mi]= min(avp(submaxpts));
                maxs{k}(i-1)= submaxpts(av2mi);
                % measure steepness of maximum
                maxsc{k}(i-1)= mean([avp(maxs{k}(i-1)-maxdist) - avp(maxs{k}(i-1)),avp(maxs{k}(i-1)+maxdist) - avp(maxs{k}(i-1))]);
                   
            end;
        end;     
        % choose steep maxima only
        cutptsmax{k}= [maxs{k}(find(maxsc{k} > maxthresh))];
    else
        cutptsmax{k}= [];
        maxsc{k}= [];
    end;
   
   
     
    % find local minima in segmented (potential points to be cut)
    minpts= [];
    for i= 1 + mindist:length(avs) - mindist
        if (avs(i - mindist) > avs(i)) & (avs(i + mindist) > avs(i))
            minpts= [minpts i];
        end;
    end;
    if ~isempty(minpts)
        % minpts contains multiple points for each minimum
        % find boundaries between sets of points
        minboundaries= unique([1 find(diff(minpts) > diffthresh) length(minpts)]);      
        if length(minpts) == 1
            mins{k}= minpts;
            % measure steepness of minimum
            minsc{k}= mean([avs(mins{k}-mindist) - avs(mins{k}),...
                    avs(mins{k}+mindist) - avs(mins{k})]);
        else
            % each minimum is the average of each set of points associated with it
            for i= 2:length(minboundaries)
                subminpts= minpts(minboundaries(i-1) + 1:minboundaries(i));
                [av2m, av2mi]= min(avs(subminpts));
                mins{k}(i-1)= subminpts(av2mi);
                % measure steepness of minimum
                minsc{k}(i-1)= mean([avs(mins{k}(i-1)-mindist) - avs(mins{k}(i-1)),avs(mins{k}(i-1)+mindist) - avs(mins{k}(i-1))]);
            end;
        end;    
       
        % choose large minima only
        cutptsmin{k}= [mins{k}(find(minsc{k} > minthresh))];
    else
        cutptsmin{k}= [];   
        minsc{k}= [];
    end;
  
   
   % find cutpts
   cutpts{k}= unique([cutptsmin{k} cutptsmax{k}]);

   
   
    % CUT CELLS
    if ~isempty(cutpts{k})
        % must cut cells
       
        % sort cutpts in order of distance from centre of thin
        [cs, csi]= sort(abs(cutpts{k} - round(length(fx)/2)));
        cutpts{k}= cutpts{k}(csi);
       
        cutx= fx(cutpts{k});
        cuty= fy(cutpts{k});
       
        % now divide the cell into seperate cells by cutting it across
        perim= bwperim(imdilate(subcell, strel('disk',1)));
      
        for i= 1:length(cutpts{k})
           
            bsize= 8;
            sxmin= max(1, cutx(i) - bsize);
            sxmax= min(size(perim,1), cutx(i) + bsize);
            symin= max(1, cuty(i) - bsize);
            symax= min(size(perim,2), cuty(i) + bsize);
            subperim= perim(sxmin:sxmax, symin:symax);
            [subperim, noperims]= bwlabel(subperim);
           
            % if noperims ~= 1  % JCR: noperims==0 causes problems below
            if noperims > 1
               
                % cutpt is not near end of cell. Go ahead and cut.
                currcell= subcell;
                [px, py]= find(subperim> 0);
               
                % find distances to perimeter from cutpt
                d= sqrt((px - bsize - 1).^2 + (py - bsize - 1).^2);
                [ds, di]= sort(d);
               
                % find first cutting point on perimeter
                cutperim1x= px(di(1)) + sxmin - 1;
                cutperim1y= py(di(1)) + symin - 1;
                colour1= subperim(px(di(1)), py(di(1)));
               
                % find second cutting point on perimeter
                colour= colour1;
                j= 2;
                while colour == colour1
                    colour= subperim(px(di(j)), py(di(j)));
                    j= j+1;
                end;
                cutperim2x= px(di(j-1)) + sxmin - 1;
                cutperim2y= py(di(j-1)) + symin - 1;
               
                % carry out cut
                subcell= drawline(currcell, [cutperim1x(1) cutperim1y(1)],...
                    [cutperim2x(1) cutperim2y(1)], 0);
                [subcell, ncut] = bwlabel(subcell, 4);
               
                % check cut
%                 rf= regionprops(subcell, 'majoraxislength');
%                 if min([rf.MajorAxisLength]) > mincelllength
%                     % accept cut if it has not created too small cells
                    currcell= subcell;
%                 else
%                     % ignore cut
%                     disp('Ignoring cut');
%                     subcell= currcell;
%                 end;
               
            end;
        end;  
    else     
        cutx= [];
       
    end;
   
end;
           
cutcell= zeros(size(cell));
cutcell(xmin:xmax, ymin:ymax)= subcell;   
if ~exist('ncut')
    ncut = 1;
end
   
% OUTPUT FIGURES

% figure output
if figs == 1
   
    figure; clf;
    title(cellno);
   
    subplot(3,1,1);
    plot(1:length(avp), avp, 'b.', 1:length(avs), avs, 'k.');
    legend('phase','segmented',-1);
    xlabel(['cell number ', num2str(cellno)]);
   
    % plot phase and thin
    subplot(3,1,2);
    cutptsim= zeros(size(thin));
    if ~isempty(cutx)
        for i= 1:length(cutx)
            cutptsim(cutx(i), cuty(i))= 1;
        end
        imshow(makergb2(subphcell, thin, cutptsim));
    else
        imshow(makergb2(subphcell, thin));
    end;

    % plot output cell
    subplot(3,1,3);
    imshowlabel(subcell);
   
    for i= 1:length(sx)-1
        disp([num2str(i),': maxsc(',num2str(size(maxsc{i},2)),') ',num2str(maxsc{i})]);
        disp([num2str(i),': minsc(',num2str(size(minsc{i},2)),') ',num2str(minsc{i})]);
    end;
end;

%--------------------------------------------------------------------------
% The function 'breakcellfluorsnaps' ends...
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% The function 'findprefixes' begins...
%--------------------------------------------------------------------------
function prefixes = findprefixes;
D = dir('*-p.tif');
prefixes = [];
for i = 1:length(D),
    name = D(i).name;
    L(i) = length(name);
    p = findstr('-p.tif',name);
    %       disp(name(1:p-4));
    prefixes{i} = name(1:p-5);
end;

delme = [];
prefixes = unique(prefixes');
for i = 2:length(prefixes),
    f = strmatch(upper(prefixes(i)),upper(prefixes(1:i-1)),'exact');
    if ~isempty(f),
        delme = [delme i];
    end;
end;
if ~isempty(delme),
    disp(['found case duplicates -- removing: ']);
    prefixes(delme),
    prefixes(delme) = [];
end;


j = 0;

for i = 1:length(prefixes),
    D = dir([char(prefixes(i)),'-*-p.tif']);
    L(i) = length(D);
    if L(i) > 1,
        j = j + 1;
        prefixes2(j) = prefixes(i);
    end;
end;

%--------------------------------------------------------------------------
% The function 'findprefixes' ends...
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% The function 'walkthin' begins...
%--------------------------------------------------------------------------

function [px, py] = walkthin(thin)
% function [px, py] = walkthin(thin)
%
% returns ordered list of points along thin
%   starting from a spur point

% add empty border
thin2= zeros(size(thin)+2);
thin2(2:end-1, 2:end-1)= thin;
nopts= length(find(thin > 0));

if nopts < 5
    px= [];
    py= [];
    return
end;

% find spurs
spur= thin2 & ~bwmorphmelow(thin2,'spur',1);
[sx, sy]= find(spur);
if isempty(sx)
    px= [];
    py= [];
    return
end;

% find path
i= 1; 
px(1)= sx(1);
py(1)= sy(1);
while any2(thin2),
    
    thin2(px(i), py(i))= 0;
    [nx, ny]= neighbours(thin2, px(i), py(i));
    
    i= i+1;
    if length(nx) > 1
        % pick closest
        dI= minI(sqrt((nx - px(i-1)).^2 + (ny - py(i-1)).^2));
        px(i)= nx(dI);
        py(i)= ny(dI);
    elseif length(nx) == 1
        px(i)= nx(1);
        py(i)= ny(1);
    else
        break;
    end;
    
    if i > nopts
        break;
    end;
        
end;

px= px - 1;
py= py - 1;
    
%--------------------------------------------------------------------------
% The function 'walkthin' ends...
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% The function 'bwmorphmelow' begins...
%--------------------------------------------------------------------------

function bw2 = bwmorphmelow(bw1,operation,n);

marg = 3;

[fx,fy] = find(bw1);
x1 = max(min(fx)-marg,1);
x2 = min(max(fx)+marg,size(bw1,1));

y1 = max(min(fy)-marg,1);
y2 = min(max(fy)+marg,size(bw1,2));

if nargin <= 2,
    Z = bwmorph(bw1(x1:x2,y1:y2),operation);
else
    Z = bwmorph(bw1(x1:x2,y1:y2),operation,n);
end;

bw2 = zeros(size(bw1));
bw2(x1:x2,y1:y2) = Z;
%--------------------------------------------------------------------------
% The function 'bwmorphmelow' ends...
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% The function 'neighbours' ends...
%--------------------------------------------------------------------------

function [nx, ny, colour]= neighbours(img, x, y, bsize)
% function [nx, ny, colour]= neighbours(img, x, y, bsize)
%
% returns neighbours (and their colours) of pt(x,y) in img
% i.e. all points lying in the edge of a square of length 2*bsize

if nargin == 3
    bsize= 1;
end;
colour= [];

% pad image
img2= zeros(size(img) + 2*bsize);
img2(bsize+1:size(img2,1)-bsize, bsize+1:size(img2,2)-bsize)= img;

% extract subimage
bxmin= x;
bxmax= x + 2*bsize;
bymin= y;
bymax= y + 2*bsize;
subimg= img2(bxmin:bxmax, bymin:bymax);
if bsize > 1
    subimg(2:2*bsize, 2:2*bsize)= zeros(2*bsize-1);
end;
subimg(bsize+1, bsize+1)= 0;

% find neighbours
[nx, ny]= find(subimg > 0);
% find pixel values of neighbours
for i= 1:length(nx)
    colour(i,1)= subimg(nx(i), ny(i));
end;

% translate back to original image
nx= nx + bxmin - 1 - bsize;
ny= ny + bymin - 1 - bsize;

%--------------------------------------------------------------------------
% The function 'neighbours' ends...
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% The function 'dekinker' begins...
%--------------------------------------------------------------------------
% 
function cutcell= dekinker(cell, radius, mincelllength, angthresh)
% function cutcell= dekinker(cell, radius, mincelllength, angthresh)
%
% cuts kinky cells by finding the angle between two points on thin a distance
%   radius away from a centre point
% cuts points whose angle is a local minimum along thin
% angthresh:        larger this is the more points are cut
% mincelllength:    cut will be ignored if it creates 'cells' smaller than this

angle=[]; % added by nitzan 21/8/2002, to take care of annoying warning
          % of uninitialized variable "angle" at line 92.
          
mindist= 5; % distance from pt used to test if it is a minimum
diffthresh= 3; % size of jump in diff of minpts  

% make sure image is black and white and not logical
cellno= max2(cell);
cell= +(cell > 0);
% cell= rmsinglepointconnections(cell);

% extract subimages
[fx, fy]= find(cell);
extra= 5;
xmin= max(min(fx) - extra, 1);
xmax= min(max(fx) + extra, size(cell,1));
ymin= max(min(fy) - extra, 1);
ymax= min(max(fy) + extra, size(cell,2));
subcell= cell(xmin:xmax, ymin:ymax);
originalsubcell= subcell;

% find thin
thin0 = bwmorphmelow(subcell, 'thin', inf);
% reduce so that there is only two spurs
thin= thin0;
spur= thin & ~bwmorphmelow(thin, 'spur', 1);
while length(find(spur)) > 2
    thin= thin & ~spur;
    spur= thin & ~bwmorphmelow(thin, 'spur', 1);
end;



% FIND ANGLES ALONG THIN
[fx,fy]= walkthin(thin);
for i= 1:length(fx)
    
    % find distances
    dist= sqrt((fx(i)-fx).^2 + (fy(i)-fy).^2);
    
    % find thetas (between 0 and 2 pi)
    thetas= pi + atan2(fy(i)-fy, fx(i)-fx);
    for j= 1:length(thetas),
        if thetas(j) < 0,
            thetas(j)= thetas(j) + 2*pi;
        end;
    end;
    
    % find points on thin between two distances
    pts{i} = find((dist > 0.75*radius) & (dist < 1.4*radius));
    if isempty(pts{i})
        
        disp(['Dekinker: no pixels near radius. Cell number: ', num2str(cellno)]);
        cutcell= bwlabel(cell, 4);
        return;
        
    else
        
        thets{i}= thetas(pts{i});
        
        % calculate thets from some arbitrary thet
        arbthet= thets{i}(1);
        dthet= [];
        for j= 2:length(thets{i}),
            dthet(j)= abs(thets{i}(j) - arbthet);
            if dthet(j) > 2*pi,
                dthet(j)= dthet(j) - 2*pi;
            elseif dthet(j) < 0,
                dthet(j)= dthet(j) + 2*pi;
            elseif dthet(j) > pi,
                dthet(j)= 2*pi-dthet(j);
            end;
            % require max angle difference between 
            % points to left of thin point and points to right
            angle(i)= max(dthet);
        end;
        
    end;
    
end;


% FIND LOCAL MINIMA IN ANGLE (potential points to be cut)
minpts= [];
for i= 1 + mindist:length(angle) - mindist
    if (angle(i - mindist) > angle(i)) & (angle(i + mindist) > angle(i))
        minpts= [minpts i];
    end;
end; 
if ~isempty(minpts)
    % minpts contains multiple points for each minimum
    % find boundaries between sets of points
    minboundaries= unique([1 find(diff(minpts) > diffthresh) length(minpts)]);
    
    % each minimum is the average of each set of points associated with it
    if length(minboundaries)> 1
        
        for i= 2:length(minboundaries)
            subminpts= minpts(minboundaries(i-1) + 1:minboundaries(i));
            ami= minI(angle(subminpts));
            mins(i-1)= subminpts(ami);
        end;
        
        % choose large minima only
        kinkpts= [mins(find(angle(mins) < angthresh))];
    else
        kinkpts= [];
    end;
    
else
    kinkpts= [];
end;



% COMBINE NEIGHBOURING POINTS
if isempty(kinkpts)
    kinkx= [];
    kinky= [];
else
    kinkx= fx(kinkpts);
    kinky= fy(kinkpts);
end;

i= 1;
while i < length(kinkx),
    
    d= sqrt((kinkx(i)-kinkx(i+1))^2 + (kinky(i)-kinky(i+1))^2);        
    if d < mincelllength
        kinkx(i)= round(mean([kinkx(i) kinkx(i+1)]));
        kinky(i)= round(mean([kinky(i) kinky(i+1)]));
        
        kinkx(i+1)= [];
        kinky(i+1)= [];
    else
        i= i + 1;
    end;
    
end;


% CUT CELLS
% now divide the cell into seperate cells by cutting it across
perim= bwperim(imdilate(subcell, strel('disk',1)));

for i= 1:length(kinkx)  
        
    % extract box around kink
    bsize= 8;
    sxmin= max(1, kinkx(i) - bsize);
    sxmax= min(size(perim,1), kinkx(i) + bsize);
    symin= max(1, kinky(i) - bsize);
    symax= min(size(perim,2), kinky(i) + bsize);
    subperim= perim(sxmin:sxmax, symin:symax);
    [subperim, noperims]= bwlabel(subperim);
    
    if any(any(subperim)) & (noperims ~= 1),
        
        % kink is not near end of cell. Go ahead and cut.
        currcell= subcell;
        [px, py]= find(subperim> 0);
        
        % find distances to perimeter from cutpt
        d= sqrt((px - bsize - 1).^2 + (py - bsize - 1).^2);
        [ds, di]= sort(d);
        
        % find first cutting point on perimeter
        cutperim1x= px(di(1)) + kinkx(i) - bsize - 1;
        cutperim1y= py(di(1)) + kinky(i) - bsize - 1;
        colour1= subperim(px(di(1)), py(di(1)));
        
        % find second cutting point on perimeter
        colour= colour1;
        j= 2;
        while colour == colour1
            colour= subperim(px(di(j)), py(di(j)));
            j= j+1;
        end;
        cutperim2x= px(di(j-1)) + kinkx(i) - bsize - 1;
        cutperim2y= py(di(j-1)) + kinky(i) - bsize - 1;
        
        % carry out cut 
        ri= regionprops(subcell,'solidity');
        if min([cutperim1x(1),cutperim1y(1),cutperim2x(1),cutperim2y(1)])>0 & ...
                max([cutperim1x(1),cutperim2x(1)])<=size(currcell,1) & ...
                max([cutperim1y(1),cutperim2y(1)])<=size(currcell,2)
            subcell= drawline(currcell, [cutperim1x(1) cutperim1y(1)],...
                [cutperim2x(1) cutperim2y(1)], 0);
            subcell= bwlabel(subcell, 4);
        else
            subcell=currcell;
        end
        
        % check cut
        rf= regionprops(subcell, 'majoraxislength', 'solidity');
        if min([rf.Solidity]) - min([ri.Solidity]) > 0.15
            % accept cut if it increases solidity
            currcell= subcell;   
        elseif min([rf.MajorAxisLength]) > mincelllength 
            % accept cut if it has not created too small cells
            currcell= subcell;
        else
            % ignore cut
            subcell= currcell;
        end;
        
    end;
    
end;

cutcell= zeros(size(cell));
cutcell(xmin:xmax, ymin:ymax)= subcell;    


%--------------------------------------------------------------------------
% The function 'dekinker' ends...
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% The function 'carefuldilate' begins...
%--------------------------------------------------------------------------
function dL = carefuldilate(L,blob,niter,refimage)
% function dL = carefuldilate(L, blob, niter, refimage)
%
% dilates L by strel blob niter times
% if regfimage is included, points are only added that exist in refimage

if nargin < 4,
    refimage = ones(size(L));
end;
    

for i = 1:niter,
    
    LD = imdilate(L,blob);
    BW0 = (L>0);
    BW1 = imdilate(BW0,blob);
    NewPix = BW1 & ~BW0 & refimage;
    
    L(NewPix) = LD(NewPix); 
    
end;
  
dL = L;
%--------------------------------------------------------------------------
% The function 'carefuldilate' ends...
%--------------------------------------------------------------------------


%--------------------------------------------------------------------------
% Miscellaneous Functions
%--------------------------------------------------------------------------

function y = minmin(x)
    y = min(min(double(x)));

function y = max2(x)
    y = max(max(double(x)));
        
function s= any2(a)
    %  s= any2(a);
    s= any(any(a));
    
function newim = drawline(oldim,pt1,pt2,color)
    % function newim = drawline(oldim,pt1,pt2,color);

    vec = [pt2(1) - pt1(1) , pt2(2)-pt1(2)];
    D = sqrt(sum(vec.^2));
    if (D==0)
      oldim(pt1(1),pt1(2)) = color;
    else
      for d = 0:0.25:D,
        thispt = round(pt1 + vec*d/D);
        oldim(thispt(1), thispt(2)) = color;
      end
    end
    newim = oldim;
    
function imnew = renumberimage(imold)
    imnew = imold;
    u = unique(imold(:));
    for i = 2:length(u),
        imnew(imold==u(i))=i-1;
    end;

    if islogical(imnew),
        imnew = +imnew;
    end;
    
function I= minI(a);
    % function I= minI(a);
    %
    % returns index of minimum

    [am, I]= min(a);