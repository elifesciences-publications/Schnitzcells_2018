
% Writes awell snaps to format [basename - str3(condition1) - str3(condition2) '.tif']
% Does not actually rename or delete snaps, the script actually writes new snaps


%********Things for User to Change
clear all;
basename = 'sig';
numSubwells = 25; %input('Enter number of snapshots within each pad: ');
RemoveList = [198:200]; %awell #'s
testmode = 0; %set testmode to 1, for testing only, no actual renaming
%*********


%% Rename all Images to fit the basename00X-XXX-488.TIF convention
D = dir('awell-*-*.tif');
colorList = {'488' '555' '594' '647' 'Brightfield' '-y-' '-p-' '-c-' '-t-'};
channel = 'initialized_string';

%Running loop for Renaming Files
looplength = length(D);
for j = 1 : looplength
    oldname = D(j).name;

    % Determine the new filename, based on the old filename
    setpoints = strfind(oldname,'-'); pdpoints = strfind(oldname,'.');              
    stage_num = str2double(oldname(setpoints(2)+1:pdpoints(1)-1));
    condition1 =  floor((stage_num-.1)/numSubwells)+1;
    condition2 = stage_num-(condition1-1)*numSubwells;
    for clrctr = 1:length(colorList)
       if strfind(oldname,colorList{clrctr})
           channel = colorList{clrctr}; 
           if strfind(channel,'Brightfield'); channel = 'p'; end;
           if strfind(channel,'-y-'); channel = 'y'; end;
           if strfind(channel,'-p-'); channel = 'p'; end;
           % NOTE: -m- is for mBeRFP, but will be written to -c- for consitence with later code 
           if strfind(channel,'-c-'); channel = 'c'; end; 
           if strfind(channel,'-t-'); channel = 'r'; end; 
       end
    end    
    newname = [basename  ...
        num2str(condition1,'%1.3d') '-' ...
        num2str(condition2,'%1.3d') '-' ...
        channel '.tif'];
    clear channel;

    % Rename or Delete Image, or just show how Renaming would be done
    if testmode %only testing how renaming would work
         if isempty(find(RemoveList == stage_num,1))             
            disp(['Testmode   ' oldname ' to ' newname]);        
        else %otherwise delete            
            disp(['Testmode   Deleting ' oldname]);               
        end      
    else %actually do renaming and/or deleting file
        if isempty(find(RemoveList == stage_num,1)) %rename the file
            %Rename the File            
            %A = java.io.File(oldname);
            %A.renameTo(java.io.File(newname)); 
            %disp([oldname ' to ' newname]);  
            
            %Write a new file
            im = imread(oldname); 
            imwrite(im,newname,'Tiff');       
            disp([oldname ' to ' newname]);  
        else %otherwise delete
            %Delete the file
            %delete(oldname);            
            disp(['Deleting ' oldname]);               
        end       
    end   
    
end %end loop thru all iamges

clear D RemoveList basename channel clrctr colorList condition1 condition2 ans;
clear A j looplength newname numSubwells oldname pdpoints setpoints stage_num testmode;



