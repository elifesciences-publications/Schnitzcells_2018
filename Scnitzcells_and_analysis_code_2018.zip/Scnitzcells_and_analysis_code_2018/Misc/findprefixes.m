function prefixes = findprefixes;
D = dir('*-p.tif');
prefixes = [];
for i = 1:length(D),
    name = D(i).name;
    L(i) = length(name);
    p = findstr('-p.tif',name);
    %       disp(name(1:p-4));
    prefixes{i} = name(1:p-4);
end;

delme = [];
prefixes = unique(prefixes');
for i = 2:length(prefixes),
    f = strmatch(upper(prefixes(i)),upper(prefixes(1:i-1)),'exact');
    if ~isempty(f),
        delme = [delme i];
    end;
end;
if ~isempty(delme),
    disp(['found case duplicates -- removing: ']);
    prefixes(delme),
    prefixes(delme) = [];
end;


j = 0;

for i = 1:length(prefixes),
    D = dir([char(prefixes(i)),'-*-p.tif']);
    L(i) = length(D);
    if L(i) > 1,
        j = j + 1;
        prefixes2(j) = prefixes(i);
    end;
end;

%    prefixes = prefixes2;