
function y = max(x);
y = min(min(double(x)));