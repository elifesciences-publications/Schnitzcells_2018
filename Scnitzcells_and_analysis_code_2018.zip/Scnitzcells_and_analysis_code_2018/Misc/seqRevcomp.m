function y = seqRevcomp(x)


y = fliplr(x);
for ctr = 1:length(y)
   if y(ctr) == 'A'
       y(ctr) = 'T';
   elseif y(ctr) == 'a'
       y(ctr) = 't';
   elseif y(ctr) == 'T'
       y(ctr) = 'A';
   elseif y(ctr) == 't'
       y(ctr) = 'a';
   elseif y(ctr) == 'G'
       y(ctr) = 'C';
   elseif y(ctr) == 'g'
       y(ctr) = 'c';
   elseif y(ctr) == 'C'
       y(ctr) = 'G';
   elseif y(ctr) == 'c'
       y(ctr) = 'g';
   else 
       disp('input sequence was not dna');
   end    
end





end %end of main function

