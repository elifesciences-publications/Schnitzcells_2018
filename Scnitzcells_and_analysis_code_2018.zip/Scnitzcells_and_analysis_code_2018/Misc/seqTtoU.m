function y = seqTtoU(x)


y = x;

for ctr = 1:length(y)
   if y(ctr) == 'T'
       y(ctr) = 'U';
   elseif y(ctr) == 't'
       y(ctr) = 'u';
   end    
end





end %end of main function

