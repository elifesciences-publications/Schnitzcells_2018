
function y = max(x);
y = max(max(double(x)));