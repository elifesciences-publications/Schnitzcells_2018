

%%
datefolder = '\\nasbddaa6\Qusb\JiHoonLee_SURF_Summer2014\2014-08-02-movies-sigX-bacitracin-dose\sub\2014-08-02'; %no slash at end
testmode = 0;
threshold =  0.27; %cells with perim/area greater than threshold will be discarded

%% Plot Perim/Area to determine threshold
if testmode
    fldList = dir([datefolder filesep '']);
    fldList = fldList(vertcat(fldList.isdir)); %keeping only folders
    fldList = fldList(cellfun(@(x) ~isempty(strfind(x,'-')), {fldList.name})); %keeping filenames with '-'

    areavec = []; %zeros(1,length(cellnum));
    perimvec = []; %zeros(1,length(cellnum));
    for fldctr = 1:length(fldList)    
        matList = dir([datefolder filesep fldList(fldctr).name filesep 'segmentation' filesep '*.mat']);
        for matctr = 1:length(matList)
            fprintf(['mat ' num2str(matctr) ' of ' num2str(length(matList)) '   folder ' num2str(fldctr) ' of ' num2str(length(fldList))]);fprintf('\n');
            load([datefolder filesep fldList(fldctr).name filesep 'segmentation' filesep matList(matctr).name],'LNsub');

            cellnum = max(max(LNsub));
            for cellctr = 1:cellnum
                areavec = vertcat(areavec,sum(sum(LNsub == cellctr))); %#ok<AGROW>
                perimvec = vertcat(perimvec,sum(sum(bwperim(LNsub == cellctr)))); %#ok<AGROW>
            end        
            clear LNsub cellnum;
        end

        clear matList;

    end

    clear fldctr matctr fldctr cellctr cellnum matList datefolder;
end

% plotting
if testmode
    close all;
    figure; 
    hist(perimvec./areavec,100);
end

%% Modify Segmentation Files
if ~testmode
    user_input = inputdlg('Input the string y, lowercase and w/o quotes, if you really want to try to Remove Little Worm Cells'); 
    if user_input{1} == 'y'
        if threshold < 0
            error('set threshold to a positive value');
        end
        fldList = dir([datefolder filesep '']);
        fldList = fldList(vertcat(fldList.isdir)); %keeping only folders
        fldList = fldList(cellfun(@(x) ~isempty(strfind(x,'-')), {fldList.name})); %keeping filenames with '-'
        for fldctr = 1:length(fldList)
            matList = dir([datefolder filesep fldList(fldctr).name filesep 'segmentation' filesep '*.mat']);
            for matctr = 1:length(matList)
                clear LNsub Lc;
                fprintf(['mat ' num2str(matctr) ' of ' num2str(length(matList)) '   folder ' num2str(fldctr) ' of ' num2str(length(fldList))]);fprintf('\n');
                
                %load Lc if it exists...otherwise create Lc from LNsub...
                %....recall Lc is the user corrected segmentation mask, whereas LNsub is the direct result of segmentation code
                LcExists = any(cellfun(@(x) strcmp(x,'Lc'),who('-file',[datefolder filesep fldList(fldctr).name filesep 'segmentation' filesep matList(matctr).name])));
                if LcExists
                    load([datefolder filesep fldList(fldctr).name filesep 'segmentation' filesep matList(matctr).name],'Lc');
                else %if Lc does not exist
                    load([datefolder filesep fldList(fldctr).name filesep 'segmentation' filesep matList(matctr).name],'LNsub');
                    Lc = LNsub;
                end
                
                %cycle thru all cells in Lc, and remove cells that are above the threshold               
                for cellctr = 1:max(max(Lc))
                    cell_area = sum(sum(Lc == cellctr));
                    cell_perim = sum(sum(bwperim(Lc == cellctr)));
                    if cell_perim/cell_area > threshold 
                        Lc(Lc == cellctr) = 0; 
                    end
                end                       
                
                %renumber Lc so there are no 'gaps' in cell numbering
                listed_numcells = sort(nonzeros(unique(Lc(:))));
                actual_numcells = length(nonzeros(unique(Lc(:))));
                for cellctr = 1:length(listed_numcells)
                    if listed_numcells(cellctr) ~= cellctr
                        Lc(Lc == listed_numcells(cellctr)) = cellctr;
                    end         
                end
                               
                %save Lc to *.mat file...remember to APPEND!
                save([datefolder filesep fldList(fldctr).name filesep 'segmentation' filesep matList(matctr).name],'Lc','-append');               
                
                clear LNsub Lc cellctr cell_area cell_perim cellctr;
            end
        end
    end
    clear matList;
    
end

clear LcExists         areavec          datefolder       fldctr           matctr           testmode         user_input;
clear actual_numcells  basename         fldList          listed_numcells  perimvec         threshold;      
        
        
  




%% Old Code, keep it around
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% cellnum = max(max(LNsub));
% 
% areavec = zeros(1,length(cellnum));
% for ctr = 1:cellnum
%     areavec(ctr) = sum(sum(LNsub == ctr));   
% end
% 
% 
% perimvec = zeros(1,length(cellnum));
% for ctr = 1:cellnum
%     perimvec(ctr) = sum(sum(bwperim(LNsub == ctr)));    
% end
% 
% close all;
% %hist(vec,30);
% figure; set(gcf,'outerposition',[-1699-210         640         576         512]);
% imagesc(LNsub > 0);
% 
% figure; set(gcf,'outerposition',[-1116-210          642         576         512]);
% newLNsub = LNsub;
% for ctr = 1:cellnum
%    if areavec(ctr) <  200
%        newLNsub(newLNsub == ctr) = 0;
%    end    
% end
% imagesc(newLNsub > 0);
% 
% figure; set(gcf,'outerposition',[-1695-210         120         576         512]);
% newLNsub = LNsub;
% for ctr = 1:cellnum
%    if perimvec(ctr) >  250 || perimvec(ctr) < 40
%        newLNsub(newLNsub == ctr) = 0;
%    end    
% end
% imagesc(newLNsub > 0);
% 
% figure; set(gcf,'outerposition',[-1113-210         114         576         512]);
% newLNsub = LNsub;
% for ctr = 1:cellnum
%    if (perimvec(ctr)/areavec(ctr)) >  .24
%        newLNsub(newLNsub == ctr) = 0;
%    end    
% end
% imagesc(newLNsub > 0);
% 
% 
% % hist(perimvec./areavec,20);
% 
% 
% 
