




%% User Settings
%cd into directory of interest!
poslist = [4 5 6 34 35 36]; %position number, set as number, not as string
imgdir = '\\nasbddaa6\Qusb\mayfly_movie\sub';
    %no slash at end, put in the 'sub' folder
    

%% Running Segmentation on Movies
%Find datefolder name
D = dir([imgdir filesep '201*-*-*']); D = D(vertcat(D.isdir));
if length(D) ~= 1
    error('Either a date directory was not found in the sub folder, or there was more than 1 identified date folder');
end
datestr = D(1).name; 
clear D;

%Finding basename
basenamedir = dir([imgdir filesep '*-*-*-*.tif']);
basenamesetpoints = strfind(basenamedir(1).name,'-');
basename = basenamedir(1).name(1:basenamesetpoints(1)-1);  

%now running through movies and tracking each one
for posctr = 1:length(poslist)
    pos = poslist(posctr);
    p = initschnitz([basename '-' str2(pos) '_1'],...
        datestr,...
        'bacillus',...
        'rootDir',imgdir,...
        'imageDir',imgdir);
    p = trackcomplete(p); 
end

