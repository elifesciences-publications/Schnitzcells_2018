% Note if your movie has an underscore in it you are fucked
% delete('*_thumb_*');
% delete('*[None]*');

%Setting initial conditions
clear all;
% profile off
% profile clear
% profile on -detail builtin
D = dir('*_*');
D([D.isdir]) = []; %removing directories


%Running loop for Renaming Files
looplength = length(D);
for j = 1 : looplength
    %Determining what the new filename will be, based on the old filename
    oldname = D(j).name;
    setpoints = strfind(oldname,'_');
    newname = ['conditionSucC' oldname(setpoints(end-2):end)];
    
    
    
    
   
    %Renaming the File with the new filename found above
    %movefile(D(j).name,newname); %this is the old code
    oldname = D(j).name;
    A = java.io.File(oldname);
    A.renameTo(java.io.File(newname)); 

    disp([num2str(j) '  of ' num2str(looplength)]); %displaying progress
end
% profile off
% profile viewer

