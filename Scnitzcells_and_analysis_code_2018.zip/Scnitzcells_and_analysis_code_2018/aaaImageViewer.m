







%% Initial Loading
clear all;
cd(fileparts(mfilename('fullpath')));
snames = {'Sacdc001-1.mat' 'Sacdc002-1.mat' 'Sacdc003-1.mat' 'Sacdc004-1.mat'...
    'Sacdc005-1.mat' 'Sacdc006-1.mat' 'Sacdc007-1.mat' 'Sacdc008-1.mat'};
for sctr = 4:8
    load(snames{sctr},'Lqacdc*');    
end



%% Simple Viewer Code
close all; figure; set(gcf,'units','normalized','position',[.2 .2 .5 .6]);

imglst = whos('Lqacdc*');
imglst = {imglst.name};
for imgctr = 1:length(imglst)
   m = eval(imglst{imgctr});
   imagesc(m);
   pause; 
end

