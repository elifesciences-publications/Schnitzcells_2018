



%% User Settings
%cd into directory of interest!
poslist = [4 5 6 34 35 36]; %position number, set as number(or vector of numbers), not as string
imgdir = '\\nasbddaa6\Qusb\mayfly_movie\sub'; %no slash at end
    %no slash at end, put in the folder that will contain the cropped
    %images, e.g. the sub folder
    %avoid spaces in imgdir

%% Cropping the Seg Files   
% Finding datestr
D = dir([imgdir filesep '201*-*-*']); D = D(vertcat(D.isdir));
if length(D) ~= 1
    error('Either a date directory was not found in the sub folder, or there was more than 1 identified date folder');
end
datestr = D(1).name; 
clear D;

% Finding basename
basenamedir = dir([imgdir filesep '*-*-y-001.tif']);
basenamesetpoints = strfind(basenamedir(1).name,'-');
basename = basenamedir(1).name(1:basenamesetpoints(1)-1);  
% basename = 'acdc';

%now running through movies
for posctr = 1:length(poslist) %looping through all desired pos's
    pos = poslist(posctr);
    p = initschnitz([basename '-' num2str(pos,'%1.2d') '_1'],...
        datestr,...
        'bacillus',...
        'rootDir',imgdir,...
        'imageDir',imgdir);

    segFileList = dir([p.segmentationDir filesep   '*-*seg*.mat']);
    segFileList = {segFileList.name};
    for segctr = 1:length(segFileList) %looping thru all seg files of given position
        clear Lc LNsub creg yreg rreg greg xreg savelist rect newrect oldrect phsub;
        load([p.segmentationDir segFileList{segctr}],'L*','*reg','phsub');
                
        %finding the crop
        extra= 15; % <- extra number of pixels on either side of highlighted region
        [fx,fy]= find(LNsub);
        xmin= max(min(fx) - extra, 1);
        xmax= min(max(fx) + extra, size(LNsub,1));
        ymin= max(min(fy) - extra, 1);
        ymax= min(max(fy) + extra, size(LNsub,2));
        rect= [xmin ymin xmax ymax];    

        %cropping the variables:  *reg,Lc,LNsub,phsub,rect
        savelist = [];
        savelist=[savelist,'''rect''']; %#ok<*AGROW>
        if exist('creg','var')==1
            savelist=[savelist,',''creg'''];
            creg = creg(rect(1):rect(3), rect(2):rect(4));
        end
        if exist('yreg','var')==1
            savelist=[savelist,',''yreg'''];
            yreg = yreg(rect(1):rect(3), rect(2):rect(4));
        end
        if exist('greg','var')==1
            savelist=[savelist,',''greg'''];
            greg = greg(rect(1):rect(3), rect(2):rect(4));
        end
        if exist('rreg','var')==1
            savelist=[savelist,',''rreg'''];
            rreg = rreg(rect(1):rect(3), rect(2):rect(4));
        end
        if exist('xreg','var')==1
            savelist=[savelist,',''xreg'''];
            xreg = xreg(rect(1):rect(3), rect(2):rect(4));
        end
        if exist('Lc','var')==1
            savelist=[savelist,',''Lc'''];
            Lc = Lc(rect(1):rect(3), rect(2):rect(4));
        end
        if exist('LNsub','var')==1
            savelist=[savelist,',''LNsub'''];
            LNsub = LNsub(rect(1):rect(3), rect(2):rect(4));
        end
        if exist('phsub','var')==1
            savelist=[savelist,',''phsub'''];
            phsub = phsub(rect(1):rect(3), rect(2):rect(4));
        end
                
        %saving the cropped variables to the mat file, specifically saving *reg,Lc,LNsub,phsub,rect
        eval(['save(''' p.segmentationDir segFileList{segctr} ''',' savelist ',''-append'');']);     
        disp(['Pos ' num2str(posctr) '   Seg ' num2str(segctr)]);
    end %end looping through all seg files of a given position   
end %end for looping thru all positions of movie





