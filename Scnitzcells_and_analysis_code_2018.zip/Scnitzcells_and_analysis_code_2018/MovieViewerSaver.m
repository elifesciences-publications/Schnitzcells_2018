function MovieViewerSaver 
%*****************User Defined Settings
%Step 1
    %make the img directory MATLAB's current directory

%*****************Creating the GUI.
f = figure('Visible','on','Position',[360,200,450,300]);

%buttons to the right of axes
hplayRect = uicontrol('Style','pushbutton','String','Play w/ Rect','Position',[315 205 70 25]...
    ,'Callback',{@playRectbutton_Callback});
heditPosition = uicontrol('Style','edit','String','07_1','Position',[315 40 30 15]);
heditFrame = uicontrol('Style','edit','String','1 55','Position',[315 235 30 15]);
heditGrayscale = uicontrol('Style','edit','String','180 700','Position',[315 150 30 15]);
heditGrayscale2 = uicontrol('Style','edit','String','350 800 320 420','Position',[315 130 60 15],'Callback',{@heditGrayscale2_Callback});
heditOffset = uicontrol('Style','edit','String','0 0','Position',[380 130 30 15],'Callback',{@heditOffset_Callback});
hgetframes = uicontrol('Style','pushbutton','String','Get Frames','Position', [315 65 70 25],'Callback',{@getframes_Callback});
hgetNextPosframes = uicontrol('Style','pushbutton','String','Get Next Position''s Frames','Position', [395 65 50 25],'Callback',{@getNextPosframes_Callback});
hplayloaded = uicontrol('Style','pushbutton','String','Play Loaded Frames','Position',[315 100 70 25],'Callback',{@playloadedbutton_Callback});
hpopup = uicontrol('Style','popupmenu','String',{'Phase plus YFP','Phase','RFP','CFP','YFP'},'Position',[315 10 100 25],'Callback',{@popup_menu_Callback});
htext = uicontrol('Style','text','String','Select Data','Position',[100 5 100 15]);
ha = axes('Units','pixels','Position', [10 50 290 235]);

%buttons below axes
hBelgetNextPosframes = uicontrol('Style','pushbutton','String','Get Next Pos Frames','Position', [10 25 40 15],'Callback',{@getNextPosframes_Callback});
hBelback = uicontrol('Style','pushbutton','String','Back','Position', [55 25 40 15],'Callback',{@back_Callback});
hBelforward = uicontrol('Style','pushbutton','String','Forward','Position', [100 25 40 15],'Callback',{@forward_Callback});
hBelCurrFrameAsLastCropFrame = uicontrol('Style','pushbutton','String','Current Frame -> Last','Position', [145 25 40 15],'Callback',{@CurrFrameAsLastCropFrame_Callback});
hBelclicky = uicontrol('Style','pushbutton','String','Clicky','Position',[190 25 40 15],'Callback',{@clicky_Callback});
hBelSaveClicky = uicontrol('Style','pushbutton','String','SaveClicky','Position',[235 25 40 15],'Callback',...
    {@SaveClicky_Callback});

% Change units to normalized so components resize automatically.
set([f,hplayRect,heditPosition,heditFrame,hgetframes,hgetNextPosframes,hplayloaded,hpopup,htext,ha,heditGrayscale,heditGrayscale2,heditOffset],'Units','normalized');
set([hBelgetNextPosframes,hBelback,hBelforward,hBelCurrFrameAsLastCropFrame,hBelclicky,hBelSaveClicky],'Units','normalized');
set(f,'Name','MovieCropGUI2'); %Assign name to GUI
set(f,'Position',[.005 .2 .990 .73]); %bottom left corner X, bottom left corner Y, width, height
%movegui(f,'center'); %Move GUI to center of screen
%set(f,'Visible','on'); %make GUI visible

%*****************Setting initial conditions
%Finding basename
basenamedir = dir('*-*-y-001.tif');
basenamesetpoints = strfind(basenamedir(1).name,'-');
basename = basenamedir(1).name(1:basenamesetpoints(1)-1);  
clear basenamesetpoints basenamedir;

%Finding date string, if possible
D = dir('201*-*-*'); D = D(vertcat(D.isdir));
if length(D) == 1
    date_str = D(1).name; 
else
    date_str = '';
end
clear D;

%Renaming 'imgdir', which holds directory where img's are stored
%%%%%imgdir must end up having 2 backslashes for a single backslash
%%%%%also must have 2 backslashes at end of directory name
%%%%%Example1 - 'C:\\Users\\enderval3\\Desktop\\SigD.Matrix.Movie\\';
%%%%Example2 - '\\THECUSAUR\\SigB\\JinData\\2012-01-20-pspacBscreenWM-cp-rn\\';
% currdir = pwd; %currdir is a string containing current directory
% strlength = length(currdir); counter = 2;
% while counter < (strlength)
%     if currdir(counter) == '\' && currdir(counter-1) ~= '\' && currdir(counter+1) ~= '\' 
%        currdir = [currdir(1:counter) '\' currdir(counter+1:end)];
%     end
%     counter = counter + 1;
%     strlength = length(currdir);    
% end
% imgdir = [currdir '\\'];

%Setting other initial conditions
position = '07_1'; %set as string
channel  = 'p'; %set as string, without any dashes
channel2 = 'y'; %set as string, without any dashes

Mov = zeros(1,'uint16'); %Mov = zeros(1040,1392,60);
Mov1 = []; %for phase movie, when loading combined yfp, phase movie
Mov2 = []; %for phase movie, when loading combined yfp, phase movie
newMov = zeros(1,'uint16');
Rect = zeros(1,'uint16');
col = zeros(1,2);
row = zeros(1,2);
current_frame = 1;
total_frames = 1;

%*****************Function Callbacks     
    function SaveClicky_Callback(~,~)
        %CropMaskMatrix
        %position # , frameStart , frameEnd , Tmarg, Lmarg, Bmarg, Rmarg
        %everything stored as numbers, not strings
                
        %first check whether the matrix exists, if not -> make matrix
        %disp('Start Clicky Save'); 
        %if isempty(dir('CropMaskMatrix.mat'))
            %CropMaskMatrix = zeros(1,7);
        %else %if the mat file exists, then load it  
            %disp('Start Mat Load'); 
            %Ctemp = load('CropMaskMatrix.mat','CropMaskMatrix');
            %CropMaskMatrix = Ctemp(1).CropMaskMatrix;
            %disp('Done Mat Load');
        %end
        %in matrix, check whether the entry exists
        %if isempty(find(CropMaskMatrix(:,1) == str2double(position), 1)) == 0 %if pos in matrix
            %Mrow = find(CropMaskMatrix(:,1) == str2double(position));
        %else %if pos is not in matrix
            %if CropMaskMatrix(1,1) == 0
                %Mrow = 1;
            %else
                %Mrow = length(CropMaskMatrix(:,1)) + 1;
            %end
        %end
        %%then either replace old entry, or make new entry
        %CropMaskMatrix(Mrow,1) = str2double(position);
        %cropRange = str2num(get(heditFR,'String')); CropMaskMatrix(Mrow,2) = cropRange(1);
        %CropMaskMatrix(Mrow,3) = cropRange(2);
        %CropMaskMatrix(Mrow,4) = row(1)-1; %i.e. tmargin
        %CropMaskMatrix(Mrow,5) = col(1)-1; %i.e. lmargin
        %CropMaskMatrix(Mrow,6) = 1040-row(2); %i.e. bmargin
        %CropMaskMatrix(Mrow,7) = 1392-col(2); %i.e. rmargin
        %
        %%save matrix to mat file, and remove variable from workspace
        %save('CropMaskMatrix.mat','CropMaskMatrix'); %v6 avoid compression...makes everything faster
        %clear('CropMaskMatrix'); clear('Ctemp');
        %disp(['Clicky saved for position ' position]);

        % from ApplyCropMaskMatrix
        %r1 = CropMaskMatrix(posctr,4)+1; %Tmarg + 1
        %r2 = 1040-CropMaskMatrix(posctr,6); %1040-Bmarg
        %c1 = CropMaskMatrix(posctr,5) + 1; %Lmarg + 1
        %c2 = 1392 - CropMaskMatrix(posctr,7) + 1; %Rmarg + 1
        %imwrite(currimg(r1:r2,c1:c2),[writedir newname],'tif');   
        
        % Extract which cropped region to save
        if ~isempty(find(row == 0,1)) && ~isempty(find(col == 0,1)) 
            r1 = 1; r2 = size(Mov,1); c1 = 1; c2 = size(Mov,2);            
        else
            r1 = row(1); r2 = row(2);
            c1 = col(1); c2 = col(2);
        end
        
        if isempty(channel2)
            set(htext,'String','Save Start!'); 
            user_input = inputdlg(['Enter sigma factor...filename will have form: ' date_str '-' position '-' 'user_input' '.avi'],'Input!');
            mov_filename = [date_str '-' position '-' user_input{1} '.avi'];            
            writerObj = VideoWriter(mov_filename,'Uncompressed AVI'); 
            writerObj.FrameRate = 10;
            open(writerObj);

            grayRange = str2num(get(heditGrayscale,'String')); %#ok<ST2NM>
            cropRange = str2num(get(heditFrame,'String')); %#ok<ST2NM>
            for movctr = min(cropRange):max(cropRange)
                imshow(Mov(:,:,movctr),grayRange); pause(.000001);
                frame_formovie = getframe;
                writeVideo(writerObj,frame_formovie);             
            end
            close(writerObj);
            set(htext,'String','Save Done!');             
        else %below if for phase plus yfp movie
            set(htext,'String','Save Start!'); 
            user_input = inputdlg(['Enter sigma factor...filename will have form: ' date_str '-' position '-' 'user_input' '.avi'],'Input!');
            mov_filename = [date_str '-' position '-' user_input{1} '.avi'];
            writerObj = VideoWriter(mov_filename); writerObj.Quality = 100;
            %writerObj = VideoWriter(mov_filename,'Uncompressed AVI'); 
            writerObj.FrameRate = 10;
            open(writerObj);

            cropRange = str2num(get(heditFrame,'String'));  %#ok<ST2NM>
            for movctr = min(cropRange):max(cropRange)
                imshow(Mov(r1:r2,c1:c2,:,movctr)); pause(.000001);
                frame_formovie = getframe;
                writeVideo(writerObj,frame_formovie);             
            end
            close(writerObj);
            set(htext,'String','Save Done!');            
        end
        
    end
    
    function heditOffset_Callback(~,~)
        if length(channel2) ~= 1; return; end; %do nothing if only a 1 color movie is loaded
        offset = str2num(get(heditOffset,'String')); %#ok<ST2NM>  %horizontal, vertical
                %imagine pushing the yfp image, while the phase image stays in place        
        
        r1_1 = max(1,1+offset(2)); r2_1 = min(size(Mov,1),size(Mov,1)+offset(2)); %for phase
        c1_1 = max(1,1+offset(1)); c2_1 = min(size(Mov,2),size(Mov,2)+offset(1));
                
        r1_2 = max(1,1-offset(2)); r2_2 = min(size(Mov,1),size(Mov,1)-offset(2)); %for yfp
        c1_2 = max(1,1-offset(1)); c2_2 = min(size(Mov,2),size(Mov,2)-offset(1));
        
        Mov = zeros(size(Mov,1)-offset(2),size(Mov,2)-offset(1),3,size(Mov,4),'double');
        grayrange = str2num(get(heditGrayscale2,'String')); %#ok<ST2NM>  %phase_min phase_max yfp_min yfp_max                  
        for ctr = 1:size(Mov,4)
            imp = (Mov1(r1_1:r2_1,c1_1:c2_1,ctr) - grayrange(1))/(grayrange(2) - grayrange(1)); imp(imp < 0) = 0; imp(imp > 1) = 1;
            imp = repmat(imp,[1 1 3]); 
            imy = (Mov2(r1_2:r2_2,c1_2:c2_2,ctr) - grayrange(3))/(grayrange(4) - grayrange(3)); imy(imy < 0) = 0; imp(imp > 1) = 1;
            
            imp(:,:,2) = imadd(imp(:,:,2),imy);
            Mov(:,:,:,ctr) = imp;               
            imshow(Mov(:,:,:,ctr),[]); pause(0.000001);
            set(htext,'String',['Frame ' num2str(ctr) ' of ' num2str(size(Mov,4))]);         
        end     
        current_frame = size(Mov,4);
        newMov = Mov;
    end

    function heditGrayscale2_Callback(~,~)       
        if length(channel2) ~= 1; return; end; %do nothing if only a 1 color movie is loaded
        
        grayrange = str2num(get(heditGrayscale2,'String')); %#ok<ST2NM>  %phase_min phase_max yfp_min yfp_max                  
        for ctr = 1:size(Mov,4)
            imp = (Mov1(:,:,ctr) - grayrange(1))/(grayrange(2) - grayrange(1)); imp(imp < 0) = 0; imp(imp > 1) = 1;
            imp = repmat(imp,[1 1 3]); 
            imy = (Mov2(:,:,ctr) - grayrange(3))/(grayrange(4) - grayrange(3)); imy(imy < 0) = 0; imp(imp > 1) = 1;
            
            imp(:,:,2) = imadd(imp(:,:,2),imy);
            Mov(:,:,:,ctr) = imp;   
            newMov(:,:,:,ctr) = imp;   
            imshow(newMov(:,:,:,ctr),[]); pause(0.000001);
        end
    end

    function playRectbutton_Callback(~,~)
        if isempty(channel2)
            grayRange = str2num(get(heditGrayscale,'String')); %#ok<ST2NM>
            for ctr = min(str2num(get(heditFrame,'String'))):max(str2num(get(heditFrame,'String')))   %#ok<ST2NM>
                imshow(newMov(:,:,ctr),grayRange); pause(.000001);
            end                 
            current_frame = total_frames;
        elseif length(channel2) == 1
            for ctr = min(str2num(get(heditFrame,'String'))):max(str2num(get(heditFrame,'String')))   %#ok<ST2NM>
                imshow(newMov(:,:,:,ctr)); pause(.000001);
            end                 
            current_frame = total_frames;    
        end
    end

    function clicky_Callback(~,~)
       [col,row] = ginput(2);
       col = round(col);
       row = round(row);
       
       sizeMov = size(Mov);
       W = 7; %width of lines
       if isempty(channel2)
           Rect = zeros(sizeMov(1),sizeMov(2),sizeMov(3),'uint16');
           Rect(row(1):row(1)+W,col(1):col(2),:) = 9000; %top horizontal bar
           Rect(row(2):row(2)+W,col(1):col(2),:) = 9000; %bottom horizontal bar
           Rect(row(1):row(2),col(1):col(1)+W,:) = 9000; %left veritcal bar
           Rect(row(1):row(2),col(2):col(2)+W,:) = 9000; %right veritcal bar
           %add Rect to Mov
           newMov = imadd(Mov,Rect);        
       elseif length(channel2) == 1           
           Rect = zeros(size(Mov),'double');
           Rect(row(1):row(1)+W,col(1):col(2),:,:) = 9000; %top horizontal bar
           Rect(row(2):row(2)+W,col(1):col(2),:,:) = 9000; %bottom horizontal bar
           Rect(row(1):row(2),col(1):col(1)+W,:,:) = 9000; %left veritcal bar
           Rect(row(1):row(2),col(2):col(2)+W,:,:) = 9000; %right veritcal bar
           %add Rect to Mov
           newMov = imadd(Mov,Rect);                              
       end
    end

    function back_Callback(~,~)
        grayRange = str2num(get(heditGrayscale,'String')); %#ok<ST2NM>
        prev_frame = mod(current_frame-2,total_frames)+1;
        if isempty(channel2)
            imshow(newMov(:,:,prev_frame),grayRange); 
        elseif length(channel2) == 1
            imshow(Mov(:,:,:,prev_frame)); 
        end
 
        current_frame = prev_frame;
        set(htext,'String',['Frame ' num2str(current_frame) ' of ' num2str(total_frames)]);         
    end
    
    function forward_Callback(~,~)
        if isempty(channel2)
            grayRange = str2num(get(heditGrayscale,'String'));
            next_frame = mod(current_frame,total_frames)+1;
            imshow(newMov(:,:,next_frame),grayRange); 
            current_frame = next_frame;
            set(htext,'String',['Frame ' num2str(current_frame) ' of ' num2str(total_frames)]);         
        elseif length(channel2) == 1
            next_frame = mod(current_frame,total_frames)+1;
            imshow(Mov(:,:,:,next_frame)); 
            current_frame = next_frame;
            set(htext,'String',['Frame ' num2str(current_frame) ' of ' num2str(total_frames)]);         
        end
    end

    function playloadedbutton_Callback(~,~)
       if isempty(channel2)
           grayRange = str2num(get(heditGrayscale,'String'));
           sizeMov = size(Mov);
           looplength = sizeMov(3);
           for counter = 1:looplength
               imshow(Mov(:,:,counter),grayRange);           
               pause(.00001);                  
           end
           current_frame = looplength;   
       elseif length(channel2) == 1           
           for counter = 1:size(Mov,4)
               imshow(Mov(:,:,:,counter));           
               pause(.00001);                  
           end          
       end
    end

    function getframes_Callback(~,~)
       position = get(heditPosition,'String');
       set(htext,'String','Started dir command'); pause(.00001);       
       tempdir = dir([basename '-' position '-' channel '-*']);       
       set(htext,'String','Just made Directory');pause(.00001);
       
       tic;       
       %now loading images into Mov
       if isempty(channel2)
           img1 = imread(tempdir(1).name); imgsize = size(img1);
           Mov = zeros(imgsize(1),imgsize(2),length(tempdir),'uint16');
           Mov(:,:,1) = img1;
           looplength = length(tempdir);
           for this_counter = 2:looplength
              imgname = tempdir(this_counter).name;
              Mov(:,:,this_counter) = imread(imgname,'tif'); 
              set(htext,'String',['Frame ' num2str(this_counter) ' of ' num2str(looplength) ' loaded']);  pause(.00001);          
              imshow(Mov(:,:,this_counter),[]); 
           end
           readintime = toc;
           newMov = Mov;
           current_frame = looplength;
           total_frames = looplength;
           set(htext,'String',['Reading in frames took ' num2str(readintime)]);
           set(heditFrame,'String',['1 ' num2str(looplength)]);
       elseif length(channel2) == 1 %this is loading the combined phase and yfp movie
           %set space for Mov variables, which hold the movies
           img1 = imread(tempdir(1).name); imgsize = size(img1);
           Mov1 = zeros(imgsize(1),imgsize(2),length(tempdir)); %for the phase movie
           Mov2 = zeros(imgsize(1),imgsize(2),length(tempdir)); %for the yfp movie
           Mov = zeros(imgsize(1),imgsize(2),3,length(tempdir));
           
           tempdir2 = dir([basename '-' position '-' channel2 '-*']);
           img1_2 = imread(tempdir2(1).name);
           ran = str2num(get(heditGrayscale2,'String')); %#ok<ST2NM>
           tic;
           for movctr = 1:length(tempdir2)
               im1 = double(imread(tempdir(movctr).name));  Mov1(:,:,movctr) = im1; %phase frame
               im2 = double(imread(tempdir2(movctr).name)); Mov2(:,:,movctr) = im2; %yfp frame
               
               %convert phase frame to rgb
               im1 = (im1 - ran(1))/(ran(2)-ran(1)); im1(im1 > 1) = 1; im1(im1 < 0) = 0;
               im1 = repmat(im1,[1 1 3]);
               
               %convert yfp frame to rgb, and add to phase frame
               im2 = (im2 - ran(3))/(ran(4)-ran(3)); im2(im2 > 1) = 1; im2(im2 < 0) = 0;
               im1(:,:,2) = imadd(im1(:,:,2),im2);
               
               %assign the combined phase/yfp frame to Mov
               Mov(:,:,:,movctr) = im1;              
               imshow(Mov(:,:,:,movctr),[]); pause(.00001);
               set(htext,'String',['Frame ' num2str(movctr) ' of ' num2str(length(tempdir2)) ' loaded']);  pause(.00001);                
               newMov = Mov;
               current_frame = length(tempdir2);
               total_frames = length(tempdir2);
           end
           readintime = toc;
           set(htext,'String',['Reading in frames took ' num2str(readintime)]);
           set(heditFrame,'String',['1 ' num2str(length(tempdir2))]);
       end  
           
    end

    function getNextPosframes_Callback(~,~)
       position = str2(str2double(get(heditPosition,'String'))+1);
       set(heditPosition,'String',position);       
       set(htext,'String','Started dir command'); pause(.00001);       
       tempdir = dir([basename '-' position '-' channel '-*']);
       img1 = imread(tempdir(1).name);
       imgsize = size(img1);
       Mov = zeros(imgsize(1),imgsize(2),length(tempdir),'uint16');
       set(htext,'String','Just made Directory');pause(.00001);
       tic;
       
       %now loading images into Mov
       Mov(:,:,1) = img1;
       looplength = length(tempdir);
       for counter = 2:looplength
          imgname = tempdir(counter).name;
          Mov(:,:,counter) = imread(imgname,'tif'); 
          set(htext,'String',['Frame ' num2str(counter) ' of ' num2str(looplength) ' loaded']);  pause(.00001);          
          imshow(Mov(:,:,counter),[]); 
       end
       readintime = toc;
       newMov = Mov;
       current_frame = looplength;
       total_frames = looplength;
       set(htext,'String',['Reading in frames took ' num2str(readintime)]);
       set(heditFrame,'String',['1 ' num2str(looplength)]);
    end

    function popup_menu_Callback(source,~)
       str = get(source,'String');
       val = get(source,'Value');
       switch str{val}
           case 'Phase' 
               channel = 'p'; channel2 = '';
           case 'RFP'
               channel = 't'; channel2 = '';
           case 'YFP'
               channel = 'y'; channel2 = '';
           case 'CFP'
               channel = 'c'; channel2 = '';
           case 'Phase plus YFP'
               channel = 'p'; channel2 = 'y';               
       end       
    end

    function CurrFrameAsLastCropFrame_Callback(~,~)
       set(heditFrame,'String',['1 ' str2(current_frame)]);
    end
end %end of main function

%% Subfunctions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function y = str2(x)
    y = num2str(x,'%1.2d');
end

function y = str3(x) %#ok<DEFNU>
    y = num2str(x,'%5.3d');
end



